/**
 * Created by Mining force.
*/

'use strict';

const config = require('config');
const util = require('util');
const emailUtils = require('../utils/emailUtils');
const log4js = require('log4js');
const assert = require('assert');
const path = require('path');
const crypto = require('crypto');
const constants = require('../config/constants');
const responseUtil = require(constants.util);
const auth = require(constants.authMiddleware);
const async = require('async');
const monogUtils = require(constants.mongoUtils);
const resetPasswdURLBase = config.get('resetPasswdURLBase');
const User = require(constants.userModel);

// Load the logger
const logger = log4js.getLogger('forgotPassword');

function forgotPassword(app) {
  app.get('/forgot', function (req, res, next) {
    res.sendFile(path.join(constants.public, 'forgot.html'));
  });

  app.get('/change-password', function (req, res, next) {
    res.sendFile(path.join(constants.public, 'change-password.html'));
  });

  app.post('/forgot', function (req, res, next) {
    let route = 'POST /forgot';

    if (!emailUtils.isValidEmail(req.body.email)) {
      res.sendFile(path.join(constants.public, '400.html'));
      return;
    }

    var email = req.body.email;
    logger.debug('Route: [[%s]]. User [[%s]]', route, email);
    var errStr;

    async.waterfall([
      function genResetPasswdToken(done) {
        logger.info('In genResetPasswdToken. User: [[%s]]. Generating token...', email);
        crypto.randomBytes(20, function (err, buf) {
          var token = buf.toString('hex');
          if (!err) {
            logger.info('Route: [[%s]]. Function: genResetPasswdToken. User [[%s]]. Reset Password token created.',
              route, email);
          }

          done(err, token);
        });
      }, function findAccount(token, done) {
        logger.info('In findAccount. User [[%s]]', email);
        User.findOneAndUpdate({email: email},
          {resetPasswordToken: token, resetPasswordExpires: Date.now() + 3600000},
          {upsert: false, new: true }, function (err, account) {
            if (err) {
              errStr = util.format('Route: [[%s]]. Function: findAccount. User [[%s]]. Error [[%j]]',
                route, email, err);
              done(err);
              return;
            }

            if (!account) {
              errStr = util.format('Route: [[%s]]. Function: findAccount. User [[%s]] does not exist.',
                route, email);
              err = new Error(errStr);
              err.customType = 'NO_USER';
              done(err);
              return;
            }

            logger.debug('Updated account object [[%j]]', account);
            done(err, token, account);
          });

      }, function sendResetPasswdMail(token, account, done) {
        logger.debug('In sendResetPasswdMail. User [[%s]]', email);

        var resetPasswdURL = resetPasswdURLBase + token;

        var from = 'info@csctrades.com';
        var to = email;
        var subject = 'Password Reset';
        var html = constants.email_template_start + '<div><div style="font-family: Oswald, sans-serif; font-size: 20px; font-weight: 500;">' +
          'Click the button below to reset your password.</div><br>' +
          '<a href="' + resetPasswdURL + '" class="btn btn-primary">Reset Password</a><br><br><br>' +
          '<div style="word-break: break-word;">If the above button does not work, copy and paste the ' +
          'below link in your browser address bar.<br>' +
          '<div style="font-weight: 600">' + resetPasswdURL + '</div></div></div>' + constants.email_template_end;

        // Send email now.
        emailUtils.sendMail(from, to, subject, html, sendMailCB);

        function sendMailCB(err, response) {
          logger.info('Route: [[%s]]. User: [[%s]]. Function: sendMailCB', route, email);
          if (err) {
            errStr = util.format('Route: [[%s]]. User: [[%s]]. Function: sendMailCB. ' +
              'Mail could not be sent', route, email);
            done(err);
            return;
          }

          if (response.statusCode === 202) {
            logger.info('Sendgrid status code: [[%d]]',response.statusCode);
            logger.info('Sendgrid response body: [[%j]]', response.body);
            logger.info('Sendgrid headers: [[%j]]', response.headers);
            logger.info('User: [[%s]]. Passwd reset mail successfully sent', email);
          } else {
            done(err, 'GENERIC');
            return;
          }

          done(err, 'PASSWD_RESET_LINK_SENT');
        }
      }
    ], function mainCallback(err, result) {
      logger.info('In mainCallback');
      var message;
      if (err) {
        errStr = errStr
          ? errStr
          : util.format('User [[%s]]. Error: [[%j]]', email, err);
        logger.error(errStr);

        if (err.customType === 'NO_USER') {
          res.sendFile(path.join(constants.public, 'nouser.html'));
          return;
        }
        res.sendFile(path.join(constants.public, '500.html'));
        return;
      }

      res.sendFile(path.join(constants.public, 'password-link-sent.html'));
    });
  });

  app.get('/reset', function (req, res, next) {
    var route = 'GET /reset';

    User.findOne({resetPasswordToken: req.query.authToken, resetPasswordExpires: {$gt: Date.now()}},
      function (err, account) {
        if (err) {
          logger.error('Route: [[%s]]. Error: [[%j]]', route, err);
          next(err);
          return;
        }

        if (!account) {
          logger.error('No mathing Auth token found [[%s]]', req.query.authToken);
          res.sendFile(path.join(constants.public, '400.html'));
          return;
        }

        res.sendFile(path.join(constants.public, 'reset.html'));
      });
  });


  app.post('/reset', function (req, res, next) {
    let urlPath = req.path;
    let query;
    if (urlPath === '/reset') {
      query = {resetPasswordToken: req.body.authToken, resetPasswordExpires: {$gt: Date.now()}};
    }

    // todo store password, password_confirm in a variable.
    if (!req.body.password || req.body.password !== req.body['confirm-password'] ||
      (req.body.password).length < 8) {
        res.sendFile(path.join(constants.public, '400.html'));
      return;
    }

    User.findOne(query,
      function (err, account) {
        if (err) {
          logger.error('Password reset token: [[%s]]. Error: [[%j]].', req.body.authToken, err);
          return next(err);
        }
        if (!account) {
          res.sendFile(path.join(constants.public, '400.html'));
          return;
        }

        var user = account.email;
        monogUtils.resetPassword(account, req.body.password, resetPasswordCB);

        function resetPasswordCB(err, newAccount) {
          if (err) {
            logger.error('User [[%s]]. Error: [[%j]]', user, err);
            next(err);
            return;
          }

          logger.info('Account object after updating password: [[%j]]', newAccount);
          logger.info('Saving the updated account object...');
          newAccount.save(function (err, account) {
            if (err) {
              logger.error('User [[%s]]. Error: [[%j]]', user, err);
              next(err);
              return;
            }

            logger.debug('Updated account object [[%j]]', account);
            res.sendFile(path.join(constants.public, 'password-reset-successfully.html'));

            // Send email notification
            // passwordChangedNotification(user);
          });

        }
      });
  });

  app.post('/change-password', auth.authMiddleware, function (req, res, next) {
    let route = 'POST /change-password';
    let oldPassword = req.body.oldPassword;
    let password = req.body.password;
    let confPasswd = req.body.confPasswd;
    let email = req.user.email;
    logger.debug('Route: [[%s]].', route);

    if (!oldPassword || !password || password !== confPasswd ||
      (password).length < 8) {
        responseUtil.response({msg: '400', xhr: true}, req, res);
      return;
    }

    async.waterfall([
        function authenticate(done) {
      let funcName = 'authenticate';
      let authenticate = User.authenticate();
      logger.info('Function: [[%s]]', funcName);
      authenticate(email, oldPassword, authenticateCB);

      function authenticateCB(err, user) {
        let funcName = 'authenticateCB';
        if (err) {
          logger.error('Function: [[%s]]. Error while authenticating request for user [[%s]]', funcName, email);
          logger.error('Error:', err);
          done(err);
          return;
        }

        if (!user) {
          logger.error('Function: [[%s]]. Invalid Password.', funcName);
          err = new Error('Invalid password');
          err.msg = '400';
          done(err);
          return;
        }

        logger.info('Function: [[%s]]. User [[%s]] authenticated successfully.', funcName, email);
        done(null, user);
      }
    },
        function resetPassword(user, done) {
      let funcName = 'resetPassword';
      logger.info('Function: [[%s]]', funcName);

      monogUtils.resetPassword(user, req.body.password, resetPasswordCB);

      function resetPasswordCB(err, newUser) {
        let funcName = 'resetPasswordCB';
        if (err) {
          logger.error('Function: [[%s]]. User [[%s]]. Error: [[%j]]', funcName, email, err);
          done(err);
          return;
        }

        logger.info('User object after updating password: [[%j]]', newUser);
        logger.info('Saving the updated user object...');
        newUser.save(function (err, updatedUser) {
          if (err) {
            logger.error('User [[%s]]. Error while saving updated password', email);
            logger.error('Error:', err);
            done(err);
            return;
          }

          logger.debug('Password updated successfully');
          done(null, 'success');
        });

      }
    }
    ], function mainCallback(err, result) {
      let funcName = 'mainCallback';
      let msg;
      if (err) {
        msg = err.msg
          ? err.msg
          : 'GENERIC';
        responseUtil.response({ msg: msg, xhr: true}, req, res);
        return;
      }

      logger.info('Function: [[%s]]. Result: [[%s]]', funcName, result);
      responseUtil.response({ msg: 'PASSWORD_CHANGED_SUCCESSFULLY', xhr: true }, req, res);

      // Send email notification
      // passwordChangedNotification(email);
    });
  });
}

// Helper
function passwordChangedNotification(email) {
  let funcName = 'passwordChangedNotification';
  assert(email, 'Invalid email');

  let from = constants.csctrades_info_email;
  let to = email;
  let subject = 'Password changed';
  let content = 'Password changed successfully';

  // Send email now.
  emailUtils.sendMail(from, to, subject, content, sendMailCB);

  function sendMailCB(err, response) {
    let funcName = 'sendMailCB';
    logger.info('Function: [[%s]]. User: [[%s]]. Function: sendMailCB', funcName, email);
    if (err) {
      logger.error('Function: [[%s]]. User: [[%s]]. Mail could not be sent', funcName, email);
      logger.error('Function: [[%s]]. User: [[%s]]. Error: [[%s]]', funcName, email, JSON.stringify(err));
      next(err);
      return;
    }

    logger.info('Sendgrid status code: [[%d]]',response.statusCode);
    logger.info('Sendgrid response body: [[%j]]', response.body);
    logger.info('Sendgrid headers: [[%j]]', response.headers);

    if (response.statusCode === 202) {
      logger.info('User: [[%s]]. Mail sent successfully', email);
    } else {
      logger.error('Function: [[%s]]. Email: [[%s]]. Mail not sent', funcName, email);
    }
  }
}

module.exports = forgotPassword;