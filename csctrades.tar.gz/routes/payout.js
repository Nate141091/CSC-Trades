/**
 * Created by csctrades.
 */

'use strict';

const log4js = require('log4js');
const constants = require('../config/constants');
const moment = require('moment');
const path = require('path');
const auth = require(constants.authMiddleware);
const Order = require(constants.orderModel);
const Payout = require(constants.payoutModel);
const fs = require('fs');
const async = require('async');
const daily_payout_percent = constants.daily_payout_percent;

// Load the logger
const logger = log4js.getLogger('payout');

function payouts(app) {
  app.get('/payouts/csv', auth.adminAuth, function (req, res, next) {
    let route = 'GET /payouts/csv';
    logger.info('Route: [[%s]]', route);

    async.waterfall([
        function getOrders(done) {
      let funcName = 'getOrders';
      logger.info('Function: [[%s]]', funcName);
      // todo delete this
      // Order.getOrders({statuses: ['Confirmed'], now: (Date.now() + constants.one_day_milliseconds + 122222)}, getOrdersCB);
      Order.getOrders({statuses: ['Confirmed'], now: Date.now()}, getOrdersCB);

      function getOrdersCB(err, orders) {
        let funcName = 'getOrdersCB';
        if (err) {
          logger.error('Function: [[%s]]. Error while fetching orders.', funcName);
          logger.error('Error:', err);
          done(err);
          return;
        }

        logger.info('Function: [[%s]]. Total no. of orders [[%d]]', funcName, orders.length);
        done(null, orders);
      }
    },
        function calculatePayouts(orders, done) {
      let funcName = 'calculatePayouts';
      let payoutMap = {};
      logger.info('Function: [[%s]].', funcName);
      logger.trace('Orders:', orders);

      orders.forEach(function (order) {
        let user_btc_address = order.user_btc_address;
        if (payoutMap[user_btc_address]) {
          payoutMap[user_btc_address] += (order.btc * daily_payout_percent);
        } else {
          payoutMap[user_btc_address] = (order.btc * daily_payout_percent);
        }

      });

      done(null, orders, payoutMap);

    },
        function generateJsonForPayouts(orders, payoutMap, done) {
      let funcName = 'generateJsonForPayouts';
      let payoutsArr = [];
      logger.info('Function: [[%s]]', funcName);
      orders.forEach(function (order) {
        let order_amt = order.btc;
        let payoutObj = {
          order_date: order.timestamp,
          orderId: order.orderId,
          order_amt_btc: order_amt,
          daily_payout_btc: order_amt * daily_payout_percent,
          email: order.email,
          userId: order.userId,
          wallet_address: order.wallet_address,
          user_btc_address: order.user_btc_address,
          signup_date: order.signup_date
        };

        payoutsArr.push(payoutObj);
      });

      fs.writeFileSync('./payout-details.json', JSON.stringify(payoutsArr, null, 2), 'utf8');
      done(null, payoutMap);
    },
        function generateCsv(payoutMap, done) {
      let funcName = 'generateCsv';
      let responseStr = '';
      let result;
      let payoutAddresses = Object.keys(payoutMap);
      logger.info('Function: [[%s]]. Payout Map:', funcName, payoutMap);

      payoutAddresses.forEach(function (address) {
        responseStr += address + ',' + payoutMap[address] + '\n';
      });

      fs.writeFileSync('payouts.csv', responseStr, 'utf8');
      if (responseStr) {
        result = 'success';
      } else {
        result = 'No orders found';
      }

      done(null, result);
    }
    ], function mainCallback(err, result) {
      let funcName = 'mainCallback';
      if (err) {
        logger.error('Function: [[%s]].', funcName);
        logger.error('Error:', err);
        res.sendFile(path.join(constants.public, '500.html'));
        return;
      }

      logger.info('Function: [[%s]]. Result:', funcName, result);
      if (result !== 'success') {
        res.end('No orders found');
      } else {
        res.download('payouts.csv');
      }
    });

  });

  app.get('/daily-earnings', auth.authMiddleware, function (req, res, next) {
    let route = 'GET /payouts';
    let email = req.user.email;
    logger.info('Route: [[%s]]. Email: [[%s]]', route, email);
    Payout.getPayouts({email: email}, getPayoutsCB);

    function getPayoutsCB(err, docs) {
      let funcName = 'getPayoutsCB';
      if (err) {
        logger.error('Function: [[%s]]. Error while fetching payouts for [[%s]]', funcName, email);
        logger.error('Error:', err);
        res.sendFile(path.join(constants.public, '500.html'));
        return;
      }

      logger.info('Function: [[%s]]. No. of payouts given: [[%d]]', funcName, docs.length);
      // logger.trace('Docs:', docs);
      res.render('daily-earnings', { docs: docs, moment: moment });
    }
  });
}


module.exports = payouts;