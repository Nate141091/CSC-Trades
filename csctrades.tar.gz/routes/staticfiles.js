/**
 * Created by Mining Force.
 */

'use strict';

const log4js = require('log4js');
const path = require('path');
const constants = require('../config/constants');
const auth = require(constants.authMiddleware);

// Load the logger.
const logger = log4js.getLogger('staticfiles');

function staticFiles(app) {
  app.get('/', function (req, res) {
    let userObj = {};
    if (req.user) {
      userObj.isLoggedIn = true;
      userObj.isAdmin = req.user.isAdmin;
    }

    res.render('index', { userObj: userObj });
  });

  app.get('/about', function (req, res) {
    let userObj = {};
    if (req.user) {
      userObj.isLoggedIn = true;
      userObj.isAdmin = req.user.isAdmin;
    }

    res.render('about', { userObj: userObj });
  });

  app.get('/portfolio', function (req, res) {
    let userObj = {};
    if (req.user) {
      userObj.isLoggedIn = true;
      userObj.isAdmin = req.user.isAdmin;
    }

    res.render('portfolio', { userObj: userObj });
  });

  app.get('/analysis', function (req, res) {
    let userObj = {};
    if (req.user) {
      userObj.isLoggedIn = true;
      userObj.isAdmin = req.user.isAdmin;
    }

    res.render('analysis', { userObj: userObj });
  });

  app.get('/time', auth.authMiddleware, function (req, res) {
    res.send({ time: Date.now()});
  });

  app.get('/my-withdraw', function (req, res) {
    let userObj = {};
    if (req.user) {
      userObj.isLoggedIn = true;
    }

    res.render('my-withdraw', { userObj: userObj });
  });

  app.get('/daily-profit', function (req, res) {
    let userObj = {};
    if (req.user) {
      userObj.isLoggedIn = true;
    }

    res.render('daily-profit', { userObj: userObj });
  });

  app.get('/profile', auth.authMiddleware, function (req, res) {
    let userObj = {};
    if (req.user) {
      userObj = req.user.toJSON();
      userObj.isLoggedIn = true;
    }

    res.render('profile', { userObj: userObj });
  });

  app.get('/invest', auth.authMiddleware, function (req, res) {
    let userObj = {};
    if (req.user) {
      userObj = req.user.toJSON();
      userObj.isLoggedIn = true;
    }

    res.render('invest', { userObj: userObj });
  });

  app.get('/knowledge', function (req, res) {
    let userObj = {};
    if (req.user) {
      userObj.isLoggedIn = true;
    }

    res.render('knowledge', { userObj: userObj });
  });

  app.get('/contact', function (req, res) {
    let userObj = {};
    if (req.user) {
      userObj.isLoggedIn = true;
      userObj.isAdmin = req.user.isAdmin;
    }

    res.render('contact', { userObj: userObj });
  });

  app.get('/terms', function (req, res) {
    let userObj = {};
    if (req.user) {
      userObj.isLoggedIn = true;
      userObj.isAdmin = req.user.isAdmin;
    }

    res.render('terms', { userObj: userObj });
  });

  app.get('/privacy', function (req, res) {
    let userObj = {};
    if (req.user) {
      userObj.isLoggedIn = true;
      userObj.isAdmin = req.user.isAdmin;
    }

    res.render('privacy', { userObj: userObj });
  });

  app.get('/signup', function (req, res) {
    if (req.user) {
      res.redirect('/dashboard');
      return;
    }

    res.sendFile(path.join(constants.public, 'signup.html'));
  });

  app.get('/signin', function (req, res) {
    if (req.user) {
      res.redirect('/dashboard');
      return;
    }

    res.sendFile(path.join(constants.public, 'signin.html'));
  });

  app.get('/thankyou', function (req, res) {
    if (!req.user) {
      res.redirect('/signin');
      return;
    }

    res.sendFile(path.join(constants.public, 'thankyou.html'));
  });

}


module.exports = staticFiles;