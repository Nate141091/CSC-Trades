/**
 * Created by Mining force.
 */

'use strict';

const log4js = require('log4js');
const constants = require('../config/constants');
const waValidator = require('wallet-address-validator');
const User = require(constants.userModel);
const emailUtils = require(constants.emailUtils);
const path = require('path');
const async = require('async');
const auth = require(constants.authMiddleware);
const util = require(constants.util);

// Load the logger
const logger = log4js.getLogger('profile-setting');

function profile(app) {
  app.post('/change-btc-address', auth.authMiddleware, function (req, res, next) {
    let route = 'POST /change-btc-address';
    let btcAddress = req.body.btcAddress;
    let password = req.body.password;
    let userId = req.user._id;
    let email = req.user.email;
    if (!waValidator.validate(btcAddress, 'BTC')) {
      logger.error('Route: [[%s]]. Invalid bitcoin address [[%s]]', route, btcAddress);
      res.sendFile(path.join(constants.public, '400.html'));
      return;
    }

    if (typeof password !== 'string' || password.length < 8) {
      logger.error('Route: [[%s]]. Invalid password', route);
      res.sendFile(path.join(constants.public, '400.html'));
      return;
    }

    logger.info('Route: [[%s]]. Email: [[%s]]. User bitcoin address: [[%s]]',
      route, email, btcAddress);

    async.waterfall([
        function authenticate(done) {
      let funcName = 'authenticate';
      let authenticate = User.authenticate();
      logger.info('Function: [[%s]]', funcName);
      authenticate(email, password, authenticateCB);

      function authenticateCB(err, user) {
        let funcName = 'authenticateCB';
        if (err) {
          logger.error('Function: [[%s]]. Error while authenticating user [[%s]]', funcName, email);
          logger.error('Error:', err);
          done(err);
          return;
        }

        if (!user) {
          logger.error('Function: [[%s]]. Invalid Password.', funcName);
          err = new Error('Invalid password');
          err.msg = '400';
          done(err);
          return;
        }

        logger.info('Function: [[%s]]. User [[%s]] authenticated successfully.', funcName, email);
        done(null, user);
      }
    },
        function updateBtcAddress(user, done) {
      let funcName = 'updateBtcAddress';
      logger.info('Function: [[%s]]', funcName);
      User.updateBtcAddress({userId: userId, btcAddress: btcAddress}, updateBtcAddressCB);

      function updateBtcAddressCB(err, user) {
        let funcName = 'updateBtcAddressCB';
        if (err) {
          logger.error('Function: [[%s]]. Error while updating bitcoin address for user [[%s]]', funcName, email);
          logger.error('Error:', err);
          done(err);
          return;
        }

        if (!user) {
          logger.error('Function: [[%s]]. User [[%s]] not found', funcName, email);
          err = new Error('User not found');
          done(err);
          return;
        }

        logger.info('Function: [[%s]]. User\'s btc address updated successfully', funcName);
        done(null, user);
      }

    }
    ], function mainCallback(err, user) {
      let funcName = 'mainCallback';
      if (err) {
        logger.error('Function: [[%s]]. Error:', funcName, err);
        if (err.msg === '400') {
          res.sendFile(path.join(constants.public, '400.html'));
          return;
        }

        res.sendFile(path.join(constants.public, '500.html'));
        return;
      }

      logger.info('Function: [[%s]]. User: [[%j]]', funcName, user);
      res.redirect('/profile-setting');

      // Send email notification
      let from = constants.miningforce_info_email;
      let to = email;
      let subject = 'Bitcoin address changed';
      let content = 'Your bitcoin address has been changed.<br>' +
        'new bitcoin address: ' + user.user_btc_address;

      // Send email now.
      emailUtils.sendMail(from, to, subject, content, sendMailCB);

      function sendMailCB(err, response) {
        logger.info('Route: [[%s]]. User: [[%s]]. Function: sendMailCB', route, email);
        if (err) {
          logger.error('Route: [[%s]]. User: [[%s]]. Mail could not be sent', route, email);
          logger.error('Route: [[%s]]. User: [[%s]]. Error: [[%s]]', route, email, JSON.stringify(err));
          return;
        }

        logger.info('Sendgrid status code: [[%d]]',response.statusCode);
        logger.info('Sendgrid response body: [[%j]]', response.body);
        logger.info('Sendgrid headers: [[%j]]', response.headers);


        if (response.statusCode === 202) {
          logger.info('User: [[%s]]. Mail sent successfully', email);
        } else {
          logger.error('Route: [[%s]]. Email: [[%s]]. Mail not sent', route, email);
        }
      }
    });

  });
}

module.exports = profile;