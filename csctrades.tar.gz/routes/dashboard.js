/**
 * Created by csctrades.
 */

'use strict';

const log4js = require('log4js');
const request = require('request');
const moment = require('moment');
const async = require('async');
const path = require('path');
const constants = require('../config/constants');
const User = require(constants.userModel);
const Payout = require(constants.payoutModel);
const Order = require(constants.orderModel);
const auth = require(constants.authMiddleware);
const config = require('config');
const bitcoinServerBase = config.get('bitcoinServerBase');

// Load the logger
const logger = log4js.getLogger('dashboard');

function dashboard(app) {
  app.get('/dashboard', auth.authMiddleware, function (req, res, next) {
    let route = 'GET /dashboard';
    let email = req.user.email;
    let userId = req.user._id;
    let username = req.user.username;
    let userObj = req.user.toObject();
    let walletAddr = req.user.wallet_address;

    logger.info('Route: [[%s]]. User: [[%s]]. Wallet address: [[%s]]',
      route, email, walletAddr);

    // Parallely fetch user's order history from db.
    async.parallel([
        function getOrders(callback) {
      let funcName = 'getOrders';
      logger.info('Function: [[%s]]', funcName);
      Order.getOrders({ userId: userId }, getOrdersCB);

      function getOrdersCB(err, docs) {
        let funcName = 'getOrdersCB';
        if (err) {
          logger.error('Function: [[%s]]. Error while fetching order history for user [[%s]]', funcName, email);
          logger.error('Error:', err);
          callback(err);
          return;
        }

        logger.info('Function: [[%s]]. Orders fetched [[%d]]', funcName, docs.length);
        callback(null, docs);
      }
    },
        function getTotalEarned(callback) {
      let funcName = 'getTotalEarned';
      logger.info('Function: [[%s]]', funcName);

      Payout.getTotalEarned({email: email}, getTotalEarnedCB);

      function getTotalEarnedCB(err, result) {
        let funcName = 'getTotalEarnedCB';
        if (err) {
          logger.error('Function: [[%s]]. Error while fetching total earned for [[%s]]', funcName, email);
          logger.error('Error:', err);
          callback(err);
          return;
        }

        logger.debug('Function: [[%s]]. Result:', funcName, result);
        let totalEarned = result[0] ?
          result[0]
          : {totalEarned: 0};
        callback(null, totalEarned);
      }
    }
    ], function mainCallback(err, results) {
      let funcName = 'mainCallback';
      let orders = results[0];
      if (err) {
        logger.error('Function: [[%s]]. Error:', funcName, err);
        res.sendFile(path.join(constants.public, '500.html'));
        return;
      }

      userObj.orders = orders;
      userObj.totalEarned = results[1].totalEarned;

      logger.debug('Function: [[%s]]. Final user obj:', funcName, userObj);
      res.render('dashboard', { userObj: userObj, moment: moment });
    });

  });

  //  todo delete this
  /*app.get('/withdrawal', auth.authMiddleware, function (req, res, next) {
    let route = 'GET /withdrawal';
    // todo delete this
    req.user = {
      "_id" : "5916afff7dc033151ef50d66",
      "isAuthenticated" : false,
      "authToken" : "762d6ac68508653e98383a84e3a28910661c5652b57866dd6a12a7eca53af287e38e647a81a2dfd52d32394dabfb8992",
      "email" : "sunil.varghese@aaravsoftware.com",
      "timestamp" : 1494659071191,
      "wallet_address" : "357bCZWek7WYN3LPFwJv1AUBDXZUJC7bTH",
      "wallet_address_index" : 11,
      "resetPasswordExpires" : null,
      "resetPasswordToken" : null,
      "user_btc_address" : "1EZBqbJSHFKSkVPNKzc5v26HA6nAHiTXq6",
      "total_investment_unit" : "BTC",
      "total_investment" : 2,
      "__v" : 0
    };
    let email = req.user.email;
    let userId = req.user._id;
    // todo remove comment
    // let userObj = req.user.toObject();
    // todo delete this
    let userObj = req.user;
    logger.info('Route: [[%s]]. User: [[%s]]', route, email);

    Order.getOrders({ userId: userId }, getOrdersCB);

    function getOrdersCB(err, docs) {
      let funcName = 'getOrdersCB';
      if (err) {
        logger.error('Function: [[%s]]. Error while fetching order history for user [[%s]]', funcName, email);
        logger.error('Error:', err);
        res.sendFile(path.join(constants.public, '500.html'));
        return;
      }

      userObj.orders = docs;
      logger.info('Function: [[%s]]. Orders fetched [[%d]]', funcName, docs.length);
      logger.trace('Function: [[%s]]. Final user object:', funcName, userObj);
      res.render('dashboard', { userObj: userObj, moment: moment });
    }

  });*/

}

module.exports = dashboard;

