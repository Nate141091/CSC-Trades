/**
 * Created by miningforce.
 * Desc: Poor man's implementation of ACID transaction in mongodb.
 */

'use strict';

const log4js = require('log4js');
const constants = require('../config/constants');
const path = require('path');
const util = require(constants.util);
const assert = require('assert');
const async = require('async');
const Cart = require(constants.cartModel);
const Order = require(constants.orderModel);
const User = require(constants.userModel);
const auth = require(constants.authMiddleware);

// Load the logger for this file
const logger = log4js.getLogger('transaction');

function payment(app) {
  app.get('/payment', auth.authMiddleware, function (req, res, next) {
    let route = 'GET /payment';
    let userId = req.user._id;
    let email = req.user.email;
    let originalBal = req.user.balance;
    let cost = 0;
    let cost_btc;
    let txId = null;           // Store the id of saved transaction object
    let btcCache = global.btcCache;

    if (!btcCache) {
      logger.error('Route: [[%s]]. Empty btc cache', route);
      res.sendFile(path.join(constants.public, '500.html'));
      return;
    }

    logger.info('Route: [[%s]]. User: [[%s]]. Balance: [[%d]]', route, email, originalBal);
    async.waterfall([
        function fetchCart(done) {
      let funcName = 'fetchCart';
      logger.info('Route: [[%s]]. Function: [[%s]]. User: [[%s]]', route, funcName, email);
      Cart.getCart({ userId: userId }, getCartCB);

      function getCartCB(err, cartArr) {
        let funcName = 'getCartCB';
        if (err) {
          logger.error('Route: [[%s]]. Function: [[%s]].\n' +
            'Error while fetching cart for user [[%s]]', route, funcName, email);
          logger.error('Error:', err);
          err.customType = 'FETCH_CART_FAILED';
          done(err);
          return;
        }

        // No items in cart ? Stop async chain & go to the function: mainCallback 
        if (cartArr.length === 0) {
          logger.error('Route: [[%s]]. Function: [[%s]]. Cart is empty for user [[%s]]',
            route, funcName, email);
          err = new Error('Cart is empty');
          err.customType = 'EMPTY_CART';
          done(err);
          return;
        }

        cartArr.forEach(function (item) {
          let subTotal = item.price * item.quantity;
          cost += subTotal;
          item.sub_total = subTotal;
        });

        // convert cost of products from USD to BTC
        cost_btc = (cost/btcCache.bpi.USD.rate_float).toFixed(4);

        if (originalBal < cost_btc) {
          logger.error('Function: [[%s]]. Insufficient balance: [[%d]] - [[%d]] = [[%d]]',
            funcName, originalBal, cost_btc, originalBal - cost);
          err = new Error('Insufficient balance');
          err.customType = 'INSUFFICIENT_BALANCE';
          done(err);
          return;
        }

        logger.debug('Route: [[%s]]. Function: [[%s]]. No. of items in cart: [[%d]]', route, funcName, cartArr.length);
        logger.trace('Cart:', cartArr);
        done(null, cartArr);
      }
    },
        // Create ACID transaction mechanism for mongodb
        function acidTx(cartArr, done) {
      let funcName = 'acidTx';
      logger.debug('Route: [[%s]]. Function: [[%s]]. User: [[%s]]. \nCart array: [[%j]]',
        route, funcName, email, cartArr);

      /**************************** ASYNC.PARALLEL START *************************************/
      async.parallel([
          function addToTransaction(callback) {
        let funcName = 'parallel:addToTransaction';
        logger.info('Function: [[%s]]. User: [[%s]]', funcName, email);
        let txObj = {};          // Transaction object to be saved in db.
        let products = [];
        let cartArrClone = JSON.parse(JSON.stringify(cartArr));        // Create a clone of the cart

        cartArrClone.forEach(function (item) {
          delete item._id;
          delete item.status;
          products.push(item);
        });

        txObj.products = products;
        // todo remove this, can use mongodb's obj id as order id
        // txObj.orderid = 
        txObj.timestamp = Date.now();
        txObj.userId = userId;
        txObj.total_usd = cost;

        txObj.total_btc = (txObj.total_usd/btcCache.bpi.USD.rate_float).toFixed(4);

        let transaction = new Transaction(txObj);
        transaction.save(function (err, savedTx) {
          if (err) {
            logger.error('Function: [[%s]]. Error while saving transaction for user: [[%s]]', funcName, email);
            logger.error('Error:', err);
            err.customType = 'ROLLBACK_TRANSACTION_SAVE_FAILED';
            callback(err);
            return;
          }

          logger.info('Function: [[%s]]. Transaction successfully saved.', funcName);
          logger.debug('Function: [[%s]]. Saved transaction obj: [[%j]]', funcName, savedTx);
          txId = savedTx._id;
          callback(null, savedTx);
        });
      },
          function updateBalance(callback) {
        let funcName = 'updateBalance';
        logger.info('Function: [[%s]]. User: [[%s]]', funcName, email);
        let currBal = originalBal - cost_btc;
        User.updateBalance({ userId: userId, balance: currBal }, updateBalanceCB);

        // Not checking for updatedUser == null as this route won't be executed
        // if the user is not signed in.
        function updateBalanceCB(err, updatedUser) {
          let funcName = 'updateBalanceCB';
          if (err) {
            logger.error('Function: [[%s]]. Error while updating balance.', funcName);
            logger.error('Error:', err);
            err.customType = 'ROLLBACK_UPDATE_BALANCE_FAILED';
            callback(err);
            return;
          }

          logger.debug('Function: [[%s]]. User\'s balance updated successfully', funcName);
          logger.trace('Function: [[%s]]. Updated user object: [[%j]]', funcName, updatedUser);
          callback(null, updatedUser);
        }
      },
          function removeFromCart(callback) {
        let funcName = 'removeFromCart';
        logger.info('Function: [[%s]]. User: [[%s]]', funcName, email);

        Cart.updateStatus({userId: userId}, updateStatusCB);

        function updateStatusCB (err, rawResponse) {
          let funcName = 'updateStatusCB';
          if (err) {
            logger.error('Function: [[%s]]. Error while updating cart status', funcName);
            logger.error('Error:', err);
            err.customType = 'ROLLBACK_UPDATE_CART_STATUS_FAILED';
            callback(err);
            return;
          }

          if (rawResponse.nModified === 0 && rawResponse.n === 0) {
            logger.error('Function: [[%s]]. No matching document found in cart for user: [[%s]]',
              funcName, email);
            err = new Error('Cart update failed');
            err.customType = 'ROLLBACK_UPDATE_CART_STATUS_FAILED';
            callback(err);
            return;
          }

          logger.info('Function: [[%s]]. Cart item status updated successfully for user [[%s]]', funcName, email);
          logger.debug('Raw response:', rawResponse);
          callback(null, rawResponse);
        }
      }
      ], function parallelMainCallback(err, results) {
        let funcName = 'parallelMainCallback';
        if (err) {
          logger.error('Function: [[%s]]', funcName);
          done(err);
          return;
        }

        logger.trace('Function: [[%s]]. Results: [[%j]]', funcName, results);
        logger.info('Function: [[%s]]. Transaction completed successfully', funcName);
        done(null, 'success');
      });
      /**************************** ASYNC.PARALLEL END *************************************/

    }
    ], function mainCallback(err, result) {
      let funcName = 'mainCallback';
      if (err) {
        if (err.customType === 'EMPTY_CART') {
          res.sendFile(path.join(constants.public, '400.html'));
          return;
        }

        res.sendFile(path.join(constants.public, '500.html'));

        if (err.customType === 'ROLLBACK_TRANSACTION_SAVE_FAILED') {
          // Rollback after all functions in async.parallel have finished execution.
          setTimeout(function () {
            rollback({ userId: userId, email: email, originalBal: originalBal});
          }, 3000);
        } else if (err.customType === 'ROLLBACK_UPDATE_BALANCE_FAILED') {
          // Rollback after all functions in async.parallel have finished execution.
          setTimeout(function () {
            rollback({ userId: userId, txId: txId, email: email, originalBal: originalBal});
          }, 3000);
        } else if (err.customType === 'ROLLBACK_UPDATE_CART_STATUS_FAILED') {
          // Rollback after all functions in async.parallel have finished execution.
          setTimeout(function () {
            rollback({ userId: userId, txId: txId, email: email, originalBal: originalBal});
          }, 3000);
        }

        return;
      }

      logger.info('Function: [[%s]]. Transaction completed successfully', funcName);
      res.render('thankyou', {transactionId: txId});

      // Now permanently remove products from the cart
      Cart.clearCart(userId, clearCartCB);

      function clearCartCB(err, docsRemoved) {
        let funcName = 'clearCartCB';
        if (err) {
          logger.error('Function: [[%s]]. Error while clearing cart for user [[%s]]', funcName, email);
          logger.error(err);
          return;
        }

        logger.info('Function: [[%s]]. No. of products cleared from cart [[%s]]', funcName, docsRemoved);
      }

    });

  });
}


// Helper
function rollback(options) {
  let funcName = 'rollback';
  let userId = options.userId;
  let email = options.email;
  let originalBal = options.originalBal;
  let txId = options. txId;
  logger.debug('Function: [[%s]]. Options: [[%j]]', funcName, options);
  if (options.userId) {
    assert(userId, 'User id is invalid');
  }

  if (originalBal) {
    assert(typeof originalBal === 'number' && originalBal > 0);
  }

  if (options.txId) {
    assert(txId, 'Transaction id (order id) is invalid');
  }

  async.parallel([
      function rollbackTx(callback) {
    let funcName = 'rollbackTx';
    logger.info('Function: [[%s]]', funcName);
    if (!txId) {
      logger.info('Function: [[%s]]. No transaction id specified. Skipping....', funcName);
      callback(null);
      return;
    }

    Transaction.removeTx(txId, removeTxCB);

    function removeTxCB(err, doc) {
      let funcName = 'removeTxCB';
      if (err) {
        logger.error('Function: [[%s]]. Rollback error while deleting transaction with id: [[%s]]', funcName, txId);
        logger.error('Error:', err);
        callback(err);
        return;
      }

      logger.info('Retrieved document (boolean):', Boolean(doc));
      if (!doc) {
        logger.error('Function: [[%s]]. Transaction does not exist with Id: [[%s]]',
          funcName, txId);
        err = new Error('Missing transaction');
        callback(err);
        return;
      }

      logger.info('Transaction with id [[%s]] deleted successfully', txId);
      callback(null, 'success');
    }
  },
      function rollbackBalance(callback) {
    let funcName = 'rollbackBalance';
    logger.info('Function: [[%s]]', funcName);
    if (!userId || !originalBal) {
      logger.info('Function: [[%s]]. No userId/balance specified. Skipping....', funcName);
      callback(null);
      return;
    }

    User.updateBalance({ userId: userId, balance: originalBal }, updateBalanceCB);

    function updateBalanceCB(err, updatedUser) {
      let funcName = 'updateBalanceCB';
      if (err) {
        logger.error('Function: [[%s]]. Error while updating balance.', funcName);
        logger.error('Error:', err);
        callback(err);
        return;
      }

      logger.debug('Function: [[%s]]. Balance rollback successful', funcName);
      logger.trace('Function: [[%s]]. Updated user object: [[%j]]', funcName, updatedUser);
      callback(null, updatedUser);
    }
  },
      function rollbackCartStatus(callback) {
    let funcName = 'rollbackCartStatus';
    logger.info('Function: [[%s]]', funcName);
    if (!userId) {
      logger.info('Function: [[%s]]. No userId specified. Skipping....', funcName);
      callback(null);
      return;
    }

    Cart.updateStatus({userId: userId, rollback: true}, updateStatusCB);

    function updateStatusCB (err, rawResponse) {
      let funcName = 'updateStatusCB';
      if (err) {
        logger.error('Function: [[%s]]. Error while updating cart status', funcName);
        logger.error('Error:', err);
        callback(err);
        return;
      }

      if (rawResponse.nModified === 0 && rawResponse.n === 0) {
        logger.error('Function: [[%s]]. No matching document found in cart for user: [[%s]]',
          funcName, email);
        err = new Error('Cart update rollback failed');
        callback(err);
        return;
      }

      logger.info('Function: [[%s]]. Cart item status rollbacked successfully for user id [[%s]]', funcName, userId);
      logger.debug('Raw response:', rawResponse);
      callback(null, rawResponse);
    }
  }
  ], function mainCallback(err, results) {
    let funcName = 'rollback/mainCallback';
    if (err) {
      logger.error('Function: [[%s]]. Rollback failed', funcName);
      return;
    }

    logger.error('Function: [[%s]]. Transaction rollbacked successfully.', funcName);
  });

}

// Helper
function rollback(options) {
  let funcName = 'rollback';
  let orderId = options.orderId;
  let statusFrom = options.statusFrom;
  let statusTo = options.statusTo;

  async.parallel([
      function rollbackCartStatus() {
    let funcName = 'rollbackCartStatus';
    if () {

    }
  }
  ], function mainCallback() {

  });
}

module.exports = payment;