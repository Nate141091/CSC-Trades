/**
 * Created by csctrades.
 */

'use strict';

const log4js = require('log4js');
const constants = require('../config/constants');
const User = require(constants.userModel);
const Contact = require(constants.contactModel);
const Order = require(constants.orderModel);
const path = require('path');
const auth = require(constants.authMiddleware);
const async = require('async');
const moment = require('moment');
const Subscription = require(constants.subscriptionModel);

// Load the logger
const logger = log4js.getLogger('admin');

function admin(app) {
  app.get('/view-profiles',auth.adminAuth, function (req, res, next) {
    let route = 'GET /view-profiles';
    logger.info('Route: [[%s]]', route);

    User.getAllUsers({}, getAllUsersCB);

    function getAllUsersCB(err, users) {
      let funcName = 'getAllUsersCB';
      if (err) {
        logger.error('Function: [[%s]]. Error while fetching all users', funcName);
        logger.error('Error:', err);
        res.sendFile(path.join(constants.public, '500.html'));
        return;
      }

      logger.info('Function: [[%s]]. No. of users: [[%d]]', funcName, users.length);
      res.render('view-profiles', {users: users});
    }
  });

  app.get('/admin', auth.adminAuth, function (req, res, next) {
    let route = 'GET /admin';
    logger.info('Route: [[%s]]', route);

    async.parallel([
        function getOrders(callback) {
      let funcName = 'getOrders';
      logger.info('Function: [[%s]]', funcName);
      Order.getOrders({}, getOrdersCB);

      function getOrdersCB(err, orders) {
        let funcName = 'getOrdersCB';
        if (err) {
          logger.error('Function: [[%s]]. Error while fetching all orders', funcName);
          logger.error('Error:', err);
          callback(err);
          return;
        }

        logger.info('Function: [[%s]]. No. of orders: [[%d]]', funcName, orders.length);
        callback(null, orders);
      }
    },
        function customerExistsForPayout(callback) {
      let funcName = 'customerExistsForPayout';
      logger.info('Function: [[%s]]', funcName);
      Order.getOrders({now: Date.now(), limit: 1, statuses: ['Confirmed']}, getOrdersCB);

      function getOrdersCB(err, docs) {
        let funcName = 'getOrdersCB';
        let customerExists;
        if (err) {
          logger.error('Function: [[%s]]. Error while checking if any customer is eligible for payouts', funcName);
          logger.error('Error:', err);
          callback(err);
          return;
        }

        customerExists = docs.length > 0
          ? true
          : false;
        logger.info('----------',docs.length);
        logger.info('Function: [[%s]]. Customer exists for payouts: [[%s]]', funcName, customerExists);
        logger.debug('Docs:', docs);
        callback(null, customerExists);
      }
    }
    ], function mainCallback(err, results) {
      let funcName = 'mainCallback';
      let orders, customerExists;
      if (err) {
        logger.error('Function: [[%s]]. Error:', funcName, err);
        res.sendFile(path.join(constants.public, '500.html'));
        return;
      }

      orders = results[0];
      customerExists = results[1];
      res.render('admin', {orders: orders, moment: moment, customerExists: customerExists});
    });

  });

  app.get('/withdrawal-requests', auth.adminAuth, function (req, res, next) {
    let route = 'GET /withdrawal-requests';
    logger.info('Route: [[%s]]', route);

    Order.getOrders({ statuses: ['Withdrawal pending']}, getOrdersCB);

    function getOrdersCB(err, orders) {
      let funcName = 'getOrdersCB';
      if (err) {
        logger.error('Function: [[%s]]. Error while fetching all orders', funcName);
        logger.error('Error:', err);
        res.sendFile(path.join(constants.public, '500.html'));
        return;
      }

      logger.info('Function: [[%s]]. No. of orders fetched: [[%d]]', funcName, orders.length);
      res.render('withdrawal-requests', { orders: orders, moment: moment });
    }
  });

  app.get('/view-subscriptions', auth.adminAuth, function (req, res, next) {
    let route = 'GET /view-subscriptions';
    logger.info('Route: [[%s]]', route);

    Subscription.viewSubscriptions({}, viewSubscriptionsCB);

    function viewSubscriptionsCB(err, docs) {
      let funcName = 'viewSubscriptionsCB';
      if (err) {
        logger.error('Function: [[%s]]. Error while fetching all subscriptions', funcName);
        logger.error('Error:', err);
        res.sendFile(path.join(constants.public, '500.html'));
        return;
      }

      logger.info('Function: [[%s]]. No. of subscriptions: [[%d]]', funcName, docs.length);
      res.render('view-subscriptions', { docs: docs });
    }
  });

  app.get('/messages', function (req, res, next) {
    let route = 'GET /messages';
    logger.info('Route: [[%s]]', route);

    Contact.getContacts({}, getContactsCB);

    function getContactsCB(err, docs) {
      let funcName = 'getContactsCB';
      if (err) {
        logger.error('Function: [[%s]]. Error while fetching contact us info', funcName);
        logger.error('Error:', err);
        res.sendFile(path.join(constants.public, '500.html'));
        return;
      }

      logger.info('Function: [[%s]]. No. of docs: [[%d]]', funcName, docs.length);
      // todo delete this
      logger.debug('-----------------', docs);
      res.render('messages', { docs: docs });
    }
  });
}


module.exports = admin;