/**
 * Created by miningforce.
 */

'use strict';

const log4js = require('log4js');
const constants = require('../config/constants');
const Transaction = require(constants.txModel);
const util = require(constants.util);

// Load the logger
const logger = log4js.getLogger('txStatus');

function txStatus(app) {
  app.post('/tx/status', function (req, res, next) {
    let route = 'POST /tx/status';
    let txId = req.body.txId;
    if (typeof txId !== 'string' || txId.length === 0) {
      logger.error('Route: [[%s]]. Invalid tx id [[%s]]', route, txId);
      util.response({ msg: 'INVALID_TX_ID', xhr: true }, req, res);
      return;
    }

    logger.debug('Route: [[%s]]. Transaction id: [[%s]]', route, txId);
    Transaction.getStatusFromTxId({ txId: txId}, getStatusFromTxIdCB);

    function getStatusFromTxIdCB(err, txObj) {
      let funcName = 'getStatusFromTxIdCB';
      if (err) {
        logger.error('Function: [[%s]]. Error while fetching status for tx id [[%s]]', funcName, txId);
        logger.error('Error:', err);
        util.response({ msg: 'GENERIC', xhr: true }, req, res);
        return;
      }

      if (!txObj) {
        logger.error('Function: [[%s]]. No transaction found for this id [[%s]]', funcName, txId);
        util.response({ msg: 'NO_SUCH_TX', xhr: true }, req, res);
        return;
      }

      logger.debug('Function: [[%s]]. Transaction obj:', funcName, txObj);
      res.send({
        status: 200,
        txStatus: txObj.status,
        orderId: txObj._id
      });
    }

  });
}

module.exports = txStatus;