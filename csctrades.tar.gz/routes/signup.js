/**
 * Created by miningforce.
 */
'use strict';

const helper = require('sendgrid').mail;
const express = require('express');
const waValidator = require('wallet-address-validator');
const path = require('path');
const constants = require('../config/constants');
const util = require(constants.util);
const log4js = require('log4js');
const btc = require(constants.btc);
const config = require('config');
const User = require('../models/user');
const emailUtils = require('../utils/emailUtils');
const authenticationURLBase = config.get('authenticationURLBase');

// Load the logger
const logger = log4js.getLogger('signup');

function register(app) {
  app.post('/signup', function (req, res, next) {
    let route = 'POST /signup';
    let password = req.body.password;
    let confPasswd = req.body['confirm-password'];
    let email = req.body.email ? (req.body.email).trim() : null;
    let btcAddress = req.body.btcAddress ? (req.body.btcAddress).trim() : null;
    let referrer = null;
    if (!emailUtils.isValidEmail(email)) {
      logger.error('Route: [[%s]]. Invalid email: [[%s]]', route, email);
      res.sendFile(path.join(constants.public, '400.html'));
      return;
    }

    if (!waValidator.validate(btcAddress, 'BTC')) {
      logger.error('Route: [[%s]]. Invalid bitcoin address [[%s]]', route, btcAddress);
      res.sendFile(path.join(constants.public, '400.html'));
      return;
    }

    if (!password || password.length < 8 || password !== confPasswd) {
      logger.error('Route: [[%s]]. Password & confirm password do not match', route);
      res.sendFile(path.join(constants.public, '400.html'));
      return;
    }

    logger.debug('Route: [[%s]]. Email: [[%s]]. Bitcoin address: [[%s]]',
      route, email, btcAddress);

    if (referrer) {
      // referrer length must be between 3 & 8 chars
      if (typeof referrer !== 'string' || !(/^[a-zA-Z0-9]{3,8}$/).test(referrer) ) {
        logger.error('Route: [[%s]]. Invalid referrer [[%s]]', route, referrer);
        res.sendFile(path.join(constants.public, '400.html'));
        return;
      }

      User.isValidUser(referrer, function (err, userObj) {
        if (err) {
          logger.error('Route: [[%s]]. User: [[%s]]', route, email);
          logger.error('Error:', err);
          res.sendFile(path.join(constants.public, '500.html'));
          return;
        }

        if (!userObj) {
          logger.error('Route: [[%s]]. User: [[%s]]. Referrer [[%s]] does not exist',
            route, email, referrer);
          res.sendFile(path.join(constants.public, '404.html'));
          return;
        }

        logger.info('Referrer [[%s]] exists', referrer);
        logger.trace('Referrer: [[%s]]. User object: [[%j]]', referrer, userObj);
        register();
      });
    } else {
      referrer = null;
      register();
    }

    function register () {
      btc.getWalletAddress(function (err, walletAddressObj) {
        if (err) {
          logger.error('Route: [[%s]]. User: [[%s]]. Error: [[%j]]', route, email, err);
          err.status = 500;
          next(err);
          return;
        }

        let userObj = {
          email: email,
          timestamp: Date.now(),
          wallet_address: walletAddressObj.wallet_address,
          wallet_address_index: walletAddressObj.index,
          user_btc_address: btcAddress
        };
        logger.debug('Registering user [[%s]]. User object: [[%j]]', email, userObj);
        User.register(new User(userObj),
            req.body.password, function (err, userObj) {
          if (err) {
            logger.error('Route: [[%s]]. User: [[%s]].', route, email);
            logger.error('Error:', err);

            if (err.code === 11000) {
              let msg = (err.message).split("index: ")[1].split("dup key")[0];
              let index = msg.substring(0, msg.lastIndexOf('_'));
              logger.error('Duplicate key [[%s]]', index);

              if (index === 'username') {
                res.sendFile(path.join(constants.public, '500.html'));
                return;
              } else if (index === 'wallet_address') {
                emailUtils.duplicateKeyAlert(new Date(), email);
                res.sendFile(path.join(constants.public, '500.html'));
                return;
              }

            }

            // User already exists ? send 400 error page
            res.sendFile(path.join(constants.public, '400.html'));
            return;
          }

          logger.info('Route: [[%s]]. User [[%s]] registered successfully', route, email);
          // Send email verification
          let authenticationURL = authenticationURLBase + userObj.authToken;
          let from = constants.csctrades_info_email;
          let to = userObj.email;
          let subject = 'Confirm your email';
          let content = constants.email_template_start + '<div style="font-family: Oswald, sans-serif; font-size: 20px; font-weight: 500; ">' +
            'Click the button below to verify your email.</div><br>' +
            '<a href="' + authenticationURL + '" class="btn btn-primary">Verify Email</a><br><br><br><div style="word-break: break-word;">' +
            'If the above button does not work, copy and paste the below link in your browser address bar.<br>' +
            '<div style="font-weight: 600">' + authenticationURL + '</div></div>' + constants.email_template_end;


          // Send email now.
          emailUtils.sendMail(from, to, subject, content, sendMailCB);

          function sendMailCB(err, response) {
            logger.info('Route: [[%s]]. User: [[%s]]. Function: sendMailCB', route, email);
            if (err) {
              logger.error('Route: [[%s]]. User: [[%s]]. Mail could not be sent', route, email);
              logger.error('Route: [[%s]]. User: [[%s]]. Error: [[%s]]', route, email, JSON.stringify(err));
              next(err);
              return;
            }

            logger.info('Sendgrid status code: [[%d]]',response.statusCode);
            logger.info('Sendgrid response body: [[%j]]', response.body);
            logger.info('Sendgrid headers: [[%j]]', response.headers);

            if (response.statusCode === 202) {
              logger.info('User: [[%s]]. Mail sent successfully', email);
              res.redirect('/email-verification');
            } else {
              logger.error('Route: [[%s]]. Email: [[%s]]. Mail not sent', route, email);
              res.sendFile(path.join(constants.public, '500.html'));
            }
          }
        });
      });
    }
  }); 


  app.get('/email-verification', function (req, res) {
    res.sendFile(path.join(constants.public, 'email-verification-sent.html'));
  });

  app.get('/verify', function(req, res) {
    let route = 'GET /verify';
    User.verifyEmail(req.query.authToken, function(err, existingUser) {
      if(err) {
        logger.error('Route: [[%s]]. Error: [[%j]]', route, err);
        next(err);
        return;
      }

      logger.info('User [[%s]] verified successfully.', existingUser.email);
      res.sendFile(path.join(constants.public, 'email-verified.html'));
    });
  });

  app.post('/chk-username', function (req, res, next) {
    let route = 'POST /chk-username';
    let username = req.body.username;
    if(/^[a-z0-9]{3,8}$/.test(username) === false) {
      logger.error('Route: [[%s]]. Invalid username [[%s]]', route, username);
      util.response({msg: '400', xhr: true}, req, res);
      return;
    }

    logger.debug('Route: [[%s]]. Username: [[%s]]', route, username);

    User.fetchByUsername({ username: username }, fetchByUsernameCB);

    function fetchByUsernameCB(err, user) {
      let funcName = 'fetchByUsernameCB';
      let userExists = true;
      if (err) {
        logger.error('Function: [[%s]]. Error while fetching username [[%s]]', funcName, username);
        logger.error('Error:', err);
        util.response({msg: 'GENERIC', xhr: true}, req, res);
        return;
      }

      if (!user) {
        userExists = false;
      }

      logger.info('Function: [[%s]]. Username [[%s]] exists: [[%s]]', funcName, username, userExists);
      res.send({status: 200, userExists: userExists});
    }
  });

  app.post('/chk-email', function (req, res, next) {
    let route = 'POST /chk-email';
    let email = req.body.email;
    if (!emailUtils.isValidEmail(email)) {
      logger.error('Route: [[%s]]. Invalid email [[%s]]', route, email);
      util.response({msg: '400', xhr: true}, req, res);
      return;
    }

    logger.debug('Route: [[%s]]. Email: [[%s]]', route, email);

    User.findByEmail({ email: email }, findByEmailCB);

    function findByEmailCB(err, user) {
      let funcName = 'findByEmailCB';
      let userExists = true;
      if (err) {
        logger.error('Function: [[%s]]. Error while fetching email [[%s]]', funcName, email);
        logger.error('Error:', err);
        util.response({msg: 'GENERIC', xhr: true}, req, res);
        return;
      }

      if (!user) {
        userExists = false;
      }

      logger.info('Function: [[%s]]. Email [[%s]] exists: [[%s]]', funcName, email, userExists);
      res.send({status: 200, userExists: userExists});
    }
  });
}


module.exports = register;

