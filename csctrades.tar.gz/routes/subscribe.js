/**
 * Created by Csctrades.
 */

'use strict';

const log4js = require('log4js');
const constants = require('../config/constants');
const util = require(constants.util);
const path = require('path');
const credentials = require('../config/my-project-b7fde15c927a.json');
const emailUtils = require(constants.emailUtils);
const GoogleSpreadsheet = require('google-spreadsheet');
const async = require('async');
const doc = new GoogleSpreadsheet(constants.spreadSheetId);
const worksheetId = constants.worksheetId;
const Subscription = require(constants.subscriptionModel);

// Load the logger
const logger = log4js.getLogger('subscribe');

function subscribe(app) {
  /*app.post('/subscribe', function (req, res, next) {
    let route = 'POST /subscribe';
    let email = (typeof req.body.email === 'string') ? (req.body.email).trim() : null;

    let from = constants.contactusEmail;
    let to = constants.contactusEmail;
    let subject = 'Subscription';
    let content = '<div>Hi,<br> Subscription received!. <br><br><u>Details:</u><br>' +
      '<br> Email: ' + email + '<br></div>';

    logger.info('Route: [[%s]]. Email: [[%s]]', route, email);

    // Send email now.
    emailUtils.sendMail(from, to, subject, content, sendMailCB);

    function sendMailCB(err, response) {
      logger.info('Route: [[%s]]. Function: sendMailCB', route);
      if (err) {
        logger.error('Route: [[%s]]. Mail could not be sent', route);
        logger.error('Error: [[%s]]', JSON.stringify(err));
        res.sendFile(path.join(constants.public, '500.html'));
        return;
      }

      logger.info('Sendgrid status code: [[%d]]',response.statusCode);
      logger.info('Sendgrid response body: [[%j]]', response.body);
      logger.info('Sendgrid headers: [[%j]]', response.headers);

      if (response.statusCode === 202) {
        logger.info('Mail successfully sent to [[%s]]', to);
        res.sendFile(path.join(constants.public, 'subscribeSuccess.html'));
      } else {
        logger.error('Sendgrid status code: [[%d]]', response.statusCode);
        res.sendFile(path.join(constants.public, '500.html'));
      }
    }

  });*/

  app.post('/subscribe', function (req, res, next) {
    let route = 'POST /subscribe';
    let email = req.body.email ? (req.body.email).trim() : null;
    if (!emailUtils.isValidEmail(email)) {
      logger.error('Route: [[%s]]. Invalid email: [[%s]]', route, email);
      util.response({ msg: '400', xhr: true }, req, res);
      return;
    }

    logger.info('Route: [[%s]]. Subscriber\'s email: [[%s]]', route, email);
    const subscriber = new Subscription({ email: email });
    subscriber.save(function onSaveCB(err) {
      let funcName = 'onSaveCB';
      if (err) {
        logger.error('Function: [[%s]]. Error while saving subscriber [[%s]]', funcName, email);
        logger.error('Error:', err);
        util.response({ msg: 'GENERIC', xhr: true }, req, res);
        return;
      }

      logger.info('Function: [[%s]]. Subscriber [[%s]] saved successfully.', funcName, email);
      util.response({msg: 'SUBSCRIPTION_SUCCESS', xhr: true}, req, res);
    });
  });
}

module.exports = subscribe;