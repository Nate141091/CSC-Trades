/**
 * Created by MiningForce.
 */

'use strict';

const log4js = require('log4js');
const constants = require('../config/constants');
const Contact = require(constants.contactModel);
const path = require('path');
const credentials = require('../config/my-project-b7fde15c927a.json');
const emailUtils = require(constants.emailUtils);
const GoogleSpreadsheet = require('google-spreadsheet');
const async = require('async');
const doc = new GoogleSpreadsheet(constants.spreadSheetId);
const worksheetId = constants.worksheetId;
const util = require(constants.util);

// Load the logger
const logger = log4js.getLogger('contactUs');

function contactUs(app) {
  app.post('/contact-us', function (req, res, next) {
    let route = 'POST /contact-us';
    let name = (typeof req.body.name === 'string') ? (req.body.name).trim(): null;
    let email = (typeof req.body.email === 'string') ? (req.body.email).trim() : null;
    let message = (typeof req.body.message === 'string') ? (req.body.message).trim() : null;
    if (!emailUtils.isValidEmail(email)) {
      logger.error('Route: [[%s]]. Invalid email: [[%s]]', route, email);
      util.response({ msg: '400', xhr: true}, req, res);
      return;
    }

    if (typeof name !== 'string' || name.length > 50) {
      logger.error('Route: [[%s]]. Invalid name: [[%s]]', route, name);
      util.response({ msg: '400', xhr: true}, req, res);
      return;
    }

    if (typeof message !== 'string' || message.length > 200) {
      logger.error('Route: [[%s]]. Invalid message', route);
      util.response({ msg: '400', xhr: true}, req, res);
      return;
    }

    logger.info('Route: [[%s]]. Name: [[%s]]. Email: [[%s]].' +
      '\nMessage: [[%s]]', route, name, email, message);

    const contact = new Contact({ email: email, name: name, message: message });
    contact.save(function onSaveCB(err) {
      let funcName = 'onSaveCB';
      if (err) {
        logger.error('Function: [[%s]]. Error while saving contact info for [[%s]]', funcName, email);
        logger.error('Error:', err);
        util.response({ msg: 'GENERIC', xhr: true }, req, res);
        return;
      }

      logger.info('Function: [[%s]]. Contact info for [[%s]] saved successfully.', funcName, email);
      util.response({msg: 'CONTACT_US_SUCCESS', xhr: true}, req, res);
    });
  });
}

module.exports = contactUs;