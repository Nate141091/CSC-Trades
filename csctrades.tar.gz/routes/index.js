/**
 * Created by Mining force.
 */

'use strict';

const contactUs = require('./contactUs');
const signup = require('./signup');
const signin = require('./signin');
const ticker = require('./ticker').ticker;
const forgotPassword = require('./forgotPassword');
const dashboard = require('./dashboard');
const staticfiles = require('./staticfiles');
const subscribe = require('./subscribe');
const profileSettings = require('./profile-settings');
const payout = require('./payout');
const transactionWebhook = require('./transactionWebhook');
const withdrawal = require('./withdrawal');
const admin = require('./admin');

// Load all routes
function mountRoutes(app) {
  subscribe(app);
  contactUs(app);
  signup(app);
  signin(app);
  ticker(app);
  forgotPassword(app);
  dashboard(app);
  payout(app);
  withdrawal(app);
  staticfiles(app);
  transactionWebhook(app);
  profileSettings(app);
  admin(app);
}

module.exports = mountRoutes;
