/**
 * Created by csctrades.
 */

'use strict';

const log4js = require('log4js');
const constants = require('../config/constants');
const util = require(constants.util);
const auth = require(constants.authMiddleware);
const Order = require(constants.orderModel);
const path = require('path');
const fs = require('fs');
const moment = require('moment');
const async = require('async');

// Load the logger
const logger = log4js.getLogger('withdrawal');

function withdrawal(app) {
  app.post('/order/withdrawal', auth.xhrAuthMiddleware, function (req, res, next) {
    let route = 'POST /order/withdrawal';
    let orderId = req.body.orderId;
    if (!orderId) {
      logger.error('Route: [[%s]]. Invalid order id [[%s]]', route, orderId);
      util.response({ msg: '400', xhr: true }, req, res);
      return;
    }

    logger.info('Route: [[%s]]. Order Id: [[%s]]', route, orderId);

    async.parallel([
        function updateOrderStatus(callback) {
      let funcName = 'updateOrderStatus';
      let opt = {
        statusFrom: 'Confirmed',
        statusTo: 'Withdrawal pending',
        orderId: orderId
      };

      Order.updateStatus(opt, updateStatusCB);

      function updateStatusCB(err, order) {
        let funcName = 'updateStatusCB';
        if (err) {
          logger.error('Function: [[%s]]. Error while updating order [[%s]] status', funcName, orderId);
          logger.error('Error:', err);
          callback(err);
          return;
        }

        if (!order) {
          logger.error('Function: [[%s]]. No matching document found with status `Confirmed` in orders for orderid: [[%s]]',
            funcName, orderId);
          err = new Error('Order update failed');
          err.msg = '400';
          callback(err);
          return;
        }

        logger.info('Function: [[%s]]. Order status updated successfully for orderId [[%s]]',
          funcName, orderId);
        logger.debug('Updated order obj:', order);
        callback(null, order);
      }
    }
    ], function mainCallback(err, results) {
      let funcName = 'mainCallback';
      if (err) {
        logger.error('Function: [[%s]]. Error:', funcName, err);
        let msg = err.msg
          ? err.msg
          : 'GENERIC';
        util.response({ msg: msg, xhr: true }, req, res);
        return;
      }

      logger.info('Function: [[%s]]. Results:', funcName, results);
      util.response({ msg: 'WITHDRAWAL_REQUEST_RECEIVED', xhr: true }, req, res);
    });

  });

  app.get('/withdrawals/csv', auth.adminAuth, function (req, res, next) {
    let route = 'GET /withdrawals/csv';
    logger.info('Route: [[%s]]', route);

    async.waterfall([
        function getOrders(done) {
      let funcName = 'getOrders';
      logger.info('Function: [[%s]]', funcName);
      Order.getOrders({statuses: ['Withdrawal pending']}, getOrdersCB);

      function getOrdersCB(err, orders) {
        let funcName = 'getOrdersCB';
        if (err) {
          logger.error('Function: [[%s]]. Error while fetching orders.', funcName);
          logger.error('Error:', err);
          done(err);
          return;
        }

        logger.info('Function: [[%s]]. Total no. of orders [[%d]]', funcName, orders.length);
        done(null, orders);
      }
    },
        function calculateWithdrwalAmt(orders, done) {
      let funcName = 'calculateWithdrwalAmt';
      let withdrawalMap = {};
      logger.info('Function: [[%s]].', funcName);
      logger.trace('Orders:', orders);

      orders.forEach(function (order) {
        let user_btc_address = order.user_btc_address;
        if (withdrawalMap[user_btc_address]) {
          withdrawalMap[user_btc_address] += (order.btc);
        } else {
          withdrawalMap[user_btc_address] = (order.btc);
        }

      });

      done(null, orders, withdrawalMap);

    },
        function generateJsonForWithdrawals(orders, withdrawalMap, done) {
      let funcName = 'generateJsonForWithdrawals';
      let withdrawalsArr = [];
      logger.info('Function: [[%s]]', funcName);
      orders.forEach(function (order) {
        let withdrawalObj = {
          orderId: order.orderId,
          order_amt_btc: order.btc,
        };

        withdrawalsArr.push(withdrawalObj);
      });

      fs.writeFileSync('./withdrawals.json', JSON.stringify(withdrawalsArr, null, 2), 'utf8');
      done(null, withdrawalMap);
    },
        function generateCsv(withdrawalMap, done) {
      let funcName = 'generateCsv';
      let responseStr = '';
      let result;
      let payoutAddresses = Object.keys(withdrawalMap);
      logger.info('Function: [[%s]]. Payout Map:', funcName, withdrawalMap);

      payoutAddresses.forEach(function (address) {
        responseStr += address + ',' + withdrawalMap[address] + '\n';
      });

      fs.writeFileSync('withdrawals.csv', responseStr, 'utf8');
      if (responseStr) {
        result = 'success';
      } else {
        result = 'No orders found';
      }

      done(null, result);
    }
    ], function mainCallback(err, result) {
      let funcName = 'mainCallback';
      if (err) {
        logger.error('Function: [[%s]].', funcName);
        logger.error('Error:', err);
        res.sendFile(path.join(constants.public, '500.html'));
        return;
      }

      logger.info('Function: [[%s]]. Result:', funcName, result);
      if (result !== 'success') {
        res.end('No orders found');
      } else {
        res.download('withdrawals.csv');
      }
    });

  });

  app.get('/withdrawals', auth.authMiddleware, function (req, res, next) {
    let route = 'GET /withdrawals';
    let userId = req.user._id;
    let email = req.user.email;
    logger.debug('Route: [[%s]]. User: [[%s]]', route, email);

    Order.getOrders({ userId: userId, statuses: ['Withdrawn']}, getOrdersCB);

    function getOrdersCB(err, docs) {
      let funcName = 'getOrdersCB';
      if (err) {
        logger.error('Function: [[%s]]. Error while fetching orders for [[%s]]', funcName, email);
        logger.error('Error:', err);
        res.sendFile(path.join(constants.public, '500.html'));
        return;
      }

      logger.info('Function: [[%s]]. No. of orders: [[%d]]', funcName, docs.length);
      logger.trace('Orders:', docs);
      res.render('withdrawal', { withdrawals: docs, moment: moment });
    }

  });
}


module.exports = withdrawal;