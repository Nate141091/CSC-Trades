/**
 * Created by miningforce.
 */

'use strict';

const log4js = require('log4js');
const assert = require('assert');
const constants = require('../config/constants');
const util = require(constants.util);
const request = require('request');

// Load the logger for this file
const logger = log4js.getLogger('ticker');

function ticker(app) {
  app.get('/rates', function (req, res, next) {
    let route = 'GET /rates';
    let cache = global.exchangeRate;
    logger.debug('Route: [[%s]]. Blockchain stats Cache:', route, cache);

    res.send(cache);
  });

  app.get('/currency-rates', function (req, res, next) {
    let route = 'GET /currency-rates';
    let cache = global.currencyRate;
    logger.debug('Route: [[%s]]. Currency rates Cache:', route, cache);

    res.send(cache);
  });
}

module.exports.ticker = ticker;