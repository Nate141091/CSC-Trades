/**
 * Created by miningforce.
 */

'use strict';

const log4js = require('log4js');
const request = require('request');
const moment = require('moment');
const async = require('async');
const path = require('path');
const constants = require('../config/constants');
const User = require(constants.userModel);
const Transaction = require(constants.txModel);
const auth = require(constants.authMiddleware);
const config = require('config');
const bitcoinServerBase = config.get('bitcoinServerBase');
const referralLinkBase = config.get('referralLinkBase');

// Load the logger
const logger = log4js.getLogger('account');

function account(app) {
  app.get('/my-account', auth.authMiddleware, function (req, res, next) {
    let route = 'GET /my-account';
    let email = req.user.email;
    let balance = req.user.balance;
    let userId = req.user._id;
    let userObj = req.user.toObject();
    userObj.referralLink = referralLinkBase + userId;
    let walletAddr = req.user.wallet_address;
    let bitcoinServer = bitcoinServerBase + walletAddr;
    let options = {
      method: 'GET',
      rejectUnauthorized: false,
      uri: bitcoinServer
    };

    logger.info('Route: [[%s]]. User: [[%s]]. Wallet address: [[%s]]. Balance: [[%d]]',
      route, email, walletAddr, balance);

    // Parallely fetch info on wallet address & user's order history from db.
    async.parallel([
        function getAddressInfo(callback) {
      let funcName = 'getAddressInfo';
      logger.debug('Function: [[%s]]', funcName);

      request(options, function requestCB(err, response, responseStr) {
        let funcName = 'requestCB';
        logger.info('Function: [[%s]]', funcName);
        // Error ? just return the user object with wallet address info
        if (err || (response.statusCode !== 200 && response.statusCode !== 304)) {
          logger.error('Function: [[%s]]. User: [[%s]]. Wallet Address: [[%s]]. ' +
            'Error: [[%j]]. status Code: [[%d]]', funcName, email, walletAddr, err,
            response ? response.statusCode : null);
          // Put -1 if request has failed
          userObj.totalReceived = -1;
          callback(null, userObj);
          return;
        }

        let addrObj = JSON.parse(responseStr);
        logger.info('Function: [[%s]]. Status Code: [[%d]]', funcName, response.statusCode);
        logger.debug('Address obj:', addrObj);
        userObj.totalReceived = addrObj.totalReceived;
        callback(null, userObj);
      });
    },
        function getUserOrders(callback) {
      let funcName = 'getUserOrders';
      logger.info('Function: [[%s]]', funcName);
      Transaction.getTxs(userId, getTxsCB);

      function getTxsCB(err, docs) {
        let funcName = 'getTxsCB';
        if (err) {
          logger.error('Function: [[%s]]. Error while fetching order history for user [[%s]]', funcName, email);
          logger.error('Error:', err);
          callback(err);
          return;
        }

        logger.info('Function: [[%s]]. Orders placed [[%d]]', funcName, docs.length);
        logger.trace('Orders:', docs);
        callback(null, docs);
      }
    }
    ], function mainCallback(err, results) {
      let funcName = 'mainCallback';
      let orders, actualBalance, sum = 0;
      if (err) {
        logger.error('Function: [[%s]]. Error:', funcName, err);
        res.sendFile(path.join(constants.public, '500.html'));
        return;
      }

      orders = results[1];
      userObj.orders = orders;

      orders.forEach(function (item) {
        sum += item.total_btc;
      });

      // Update balance != incoming_funds - spent_funds
      actualBalance = userObj.totalReceived - sum;
      if (userObj.totalReceived !== -1 && balance !== actualBalance.toFixed(4)) {
        User.updateBalance({ userId: userId, balance: actualBalance }, updateBalanceCB);

        function updateBalanceCB(err, updatedDoc) {
          let funcName = 'updateBalanceCB';
          if (err) {
            logger.error('Function: [[%s]]. Error while updating balance for user [[%s]]', email);
            logger.error('Error:', err);
            res.sendFile(path.join(constants.public, '500.html'));
            return;
          }

          userObj.balance = parseFloat(updatedDoc.balance).toFixed(4).replace(/\.?0+$/,"");
          logger.trace('Function: [[%s]]. Updated doc: [[%j]]', updatedDoc);
          logger.info('Function: [[%s]]. User [[%s]]. Balance updated.', funcName, email);
          logger.debug('Function: [[%s]]. Final user obj:', funcName, userObj);
          res.render('account', { userObj: userObj , moment});
        }

      } else {
        logger.debug('Function: [[%s]]. Balance is already up to date.', funcName);
        logger.debug('Function: [[%s]]. Final user obj:', funcName, userObj);
        res.render('account', { userObj: userObj, moment});
      }
    });

  });
}

module.exports = account;