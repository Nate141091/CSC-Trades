/**
 * Created by Csctrades.
 */

'use strict';

const log4js = require('log4js');
const shortId = require('shortid');
const request = require('request');
const nodeUtil = require('util');
const assert = require('assert');
const config = require('config');
const constants = require('../config/constants');
const Order = require(constants.orderModel);
const User = require(constants.userModel);
const emailUtils = require(constants.emailUtils);
const CustomerInvestment = require(constants.customerInvestmentModel);
const min_order_amt_usd = constants.min_order_amt_usd;
const one_thash_price_usd = constants.one_thash_price_usd;
const async = require('async');
const txApiBase = config.get('BTC_SERVER_TX_API_BASE');

// Set the characters to be used for generating unique ids
shortId.characters('0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ&#');

// Load the logger
const logger = log4js.getLogger('transactionWebhook');

function webhook(app) {
  app.post('/mf/webhook/yendeidayan/ljsistk7/tx', function (req, res, next) {
    let route = 'GET /mf/webhook/yendeidayan/ljsistk7/tx';
    let txId = req.body.hash;
    let bitcoinServer = txApiBase + txId;
    // To store the addresses from the transaction object
    let addresses = [];
    req.route = route;
    let options = {
      method: 'GET',
      rejectUnauthorized: false,
      uri: bitcoinServer
    };

    logger.info('Route: [[%s]]. Request body: [[%j]]', route, req.body);

    Order.getTx({txId: txId}, function getTxCB(err, doc) {
      let funcName = 'getTxCB';
      res.end('ok');
      if (err) {
        logger.error('Function: [[%s]]. Error while fetching order from txId [[%s]]', funcName, txId);
        logger.error('Error:', err);
        return;
      }

      if (!doc) {
        logger.info('Function: [[%s]]. Transaction [[%s]] not found', funcName, txId);
        logger.info('Calling sendRequest function.............');
        sendRequest();
        return;
      }

      logger.info('Function: [[%s]]. Order found. Order id: [[%s]]', funcName, doc.orderId);
      logger.info('Calling _txConfirmed.........');
      req.hash = doc.txId;
      _txConfirmed(req, res, next);
    });

    function sendRequest() {
      let funcName = 'SendRequest';
      logger.info('Function: [[%s]]', funcName);
      // Fetch entire transaction obj from bitcore
      request(options, function requestCB(err, response, txStr) {
        let funcName = 'requestCB';
        if (err) {
          logger.error('Route:[[%s]]. Function: [[%s]]. Error:',
            route, funcName, err);
          res.status(500);
          res.end('Internal Server error');
          return;
        }

        if (response.statusCode !== 200 && response.statusCode !== 304) {
          logger.error('Route: [[%s]]. Function: [[%s]]. Failed to fetch tx id: [[%s]]', route, funcName, txId);
          res.status(500);
          res.end('Internal Server error');
          return;
        }

        let txObj = JSON.parse(txStr);
        // todo delete this
        // let confirmations = 0;
        // todo remove comment
        let confirmations = txObj.confirmations;
        req.txObj = txObj;
        logger.info('Function: [[%s]]. Status Code: [[%d]]', funcName, response.statusCode);
        logger.info('Function: [[%s]]. Confirmations: [[%s]]', funcName, confirmations);
        logger.debug('Transaction obj:', nodeUtil.inspect(txObj, false, 5, false));
        logger.info('Function: [[%s]]. Sending response 200 OK.....', funcName);
        res.end('ok');
        if (confirmations === 0) {
          _txSeen(req, res, next);
          return;
        }

        _txConfirmed(req, res, next);
      });
    }
    
  });
}


function _txConfirmed(req, res, next) {
  let funcName = '_txConfirmed';
  // todo check this
  // let txObj = req.txObj;
  let route = req.route;
  let updatedUser;
  let txId = req.hash;
  let options = {
    statusFrom: 'Pending',
    statusTo: 'Confirmed',
    txId: txId
  };

  logger.debug('Function: [[%s]]', funcName);

  async.waterfall([
      function updateOrderStatus(done) {
    let funcName = 'updateOrderStatus';
    logger.info('Function: [[%s]]', funcName);

    Order.updateStatus(options, updateStatusCB);

    function updateStatusCB(err, order) {
      let funcName = 'updateStatusCB';
      if (err) {
        logger.error('Function: [[%s]]. Error while updating order status', funcName);
        logger.error('Error:', err);
        done(err);
        return;
      }

      if (!order) {
        logger.error('Function: [[%s]]. No matching document found with status `Pending` in orders for txid: [[%s]]',
          funcName, txId);
        err = new Error('Order update failed');
        done(err);
        return;
      }

      logger.info('Function: [[%s]]. Order status updated successfully for txId [[%s]]',
        funcName, txId);
      logger.debug('Updated order obj:', order);
      done(null, order);
    }
  },
      function execParallel(order, done) {
    let funcName = 'execParallel';
    let userId = order.userId;
    let email = order.email;
    let investment = order.btc;
    let my_affiliate_bonus = 0;
    logger.info('Function: [[%s]]. Order: [[%j]]', funcName, order);

    /******************************* ASYNC: PARALLEL START *********************************/
    async.parallel([
        function updateTotalInvestment(callback) {
      let funcName = 'updateTotalInvestment';
      let options = { userId: userId, investment: investment };

      logger.info('Function: [[%s]]', funcName);
      User.updateTotalInvestment(options, updateTotalInvestmentCB);

      function updateTotalInvestmentCB(err, user) {
        let funcName = 'updateTotalInvestmentCB';
        if (err) {
          logger.error('Function: [[%s]]. Error while updating total investment for user [[%s]]',
            funcName, email);
          logger.error('Error:', err);
          callback(err);
          return;
        }

        if (!user) {
          logger.error('Function: [[%s]]. User [[%s]] not found', funcName, email);
          err = new Error('User not found');
          callback(err);
          return;
        }

        logger.info('Function: [[%s]]. User: [[%s]]. Total investment updated successfully',
          funcName, email);
        logger.trace('Updated user obj', user);
        updatedUser = user;
        callback(null, user);
      }
    },
        function incCustomersInvestment(callback) {
      let funcName = 'incCustomersInvestment';
      let type = 'customers_investment';
      logger.info('Function: [[%s]]. Customer Investment: [[%d]]', funcName, investment);

      CustomerInvestment.incInvestment({type: type, investment: investment}, incInvestmentCB);

      function incInvestmentCB(err, doc) {
        let funcName = 'incInvestmentCB';
        if (err) {
          logger.error('Function: [[%s]]. User: [[%s]]. Error while updating overall investment',
            funcName, email);
          logger.error('Error:', err);
          callback(err);
          return;
        }

        if (!doc) {
          logger.error('Function: [[%s]]. Doc type [[%s]] not found', funcName, type);
          err = new Error('Doc not found');
          callback(err);
          return;
        }

        logger.info('Function: [[%s]]. Overall customers investment updated successfully.', funcName);
        logger.trace('Doc:', doc);
        callback(null, doc);
      }
    }
    ], function mainParallelCallback(err, results) {
      let funcName = 'mainParallelCallback';
      if (err) {
        logger.error('Function: [[%s]]. Error:', funcName, err);
        done(err);
        return;
      }

      logger.info('Function: [[%s]]. Queries successfully executed in parallel', funcName);
      done(null, order);
    });
    /******************************* ASYNC: PARALLEL END ***********************************/
  },
      function sendMail(order, done) {
    let funcName = 'sendMail';
    logger.info('Function: [[%s]]', funcName);

    /******************************* ASYNC: PARALLEL START ***********************************/
    async.parallel([
        // Send acknowledgement to the customer on successful confirmation.
        function sendAck(callback) {
      let funcName = 'sendAck';
      let email = order.email;
      logger.info('Function: [[%s]]', funcName);

      // Send email acknowledgement to customer
      let from = constants.csctrades_info_email;
      let to = email;
      let subject = 'Order confirmation';
      let content = constants.email_template_start + '<div>' +
        '<div style="font-family: Oswald, sans-serif; font-size: 25px; font-weight: 500; text-align: center; text-decoration: underline;">' +
        'ORDER CONFIRMED</div><br><div><div style="width: 50%; float: left"><div>Order id</div>' +
        '<div>Order Amount</div><div>Total Investment</div></div>' +
        '<div style="width: 50%; float: right; text-align: right;"><div>' + order.orderId + '</div>' +
        '<div>' + order.btc + '</div><div>' + updatedUser.total_investment + '</div></div></div><br><br><br><br></div>';

      // Send email now.
      emailUtils.sendMail(from, to, subject, content, sendMailCB);

      function sendMailCB(err, response) {
        logger.info('Function: sendMailCB. User: [[%s]].', email);
        if (err) {
          logger.error('Route: [[%s]]. User: [[%s]]. Mail could not be sent', route, email);
          logger.error('Route: [[%s]]. User: [[%s]]. Error: [[%s]]', route, email, JSON.stringify(err));
          callback(err);
          return;
        }

        logger.info('Sendgrid status code: [[%d]]',response.statusCode);
        logger.info('Sendgrid response body: [[%j]]', response.body);

        if (response.statusCode === 202) {
          logger.info('User: [[%s]]. Mail sent successfully', email);
          callback(null, 'Mail successfully sent to the customer');
        } else {
          logger.error('Route: [[%s]]. Email: [[%s]]. Mail not sent', route, email);
          err = new Error('Mail not sent to customer');
          callback(err);
        }
      }
    }
    ], function mainParallelCallback(err, results) {
      let funcName = 'mainParallelCallback';
      if (err) {
        logger.error('Function: [[%s]]. Error:', funcName, err);
        done(err);
        return;
      }

      logger.info('Function: [[%s]]', funcName);
      logger.debug('Results:', results);
      done(null, 'success');
    });
    /******************************* ASYNC: PARALLEL END ***********************************/
  }
  ], function mainCallback(err, results) {
    let funcName = 'mainCallback';
    if (err) {
      logger.error('Function: [[%s]]', funcName);
      logger.error('Error:', err);
      return;
    }

    logger.info('Function: [[%s]]. Order confirmed for transaction id [[%s]]', funcName, txId);
    logger.debug('Results:', results);
  });
}

function _txSeen(req, res, next) {
  let funcName = '_txSeen';
  let txObj = req.txObj;
  let txId = txObj.hash;
  let addressMap = {};
  let vout = txObj.outputs;
  let walletAddress, amtSentBtc, cost_btc, userId, orderId;
  assert(Object.prototype.toString.call(txObj) === '[object Object]');
  logger.info('Function: [[%s]]', funcName);

  async.waterfall([
      function getAddressesFromTxObj(done) {
    let funcName = 'getAddressesFromTxObj';
    logger.info('Function: [[%s]]', funcName);
    vout.forEach(function (item) {

      (item.addresses).forEach(function (address) {
        addressMap[address] = {
          address: address,
          value: item.value / 100000000
        };
      });
    });

    done(null, addressMap);
  },
      function getUserFromWalletAddress (addressMap, done) {
    let funcName = 'getUserFromWalletAddress';
    // todo delete this
    /*addressMap['342gc5gHkeDYFzhinwnFVyiyydMpHVMND4'] = {
      address: '342gc5gHkeDYFzhinwnFVyiyydMpHVMND4', value: 1 
    }*/
    let addresses = Object.keys(addressMap);

    logger.debug('Function: [[%s]]. Address Map: [[%j]]', funcName, addressMap);
    User.getUserFromWalletAddress({ addresses: addresses }, getUserFromWalletAddressCB);

    function getUserFromWalletAddressCB(err, user) {
      let funcName = 'getUserFromWalletAddressCB';
      if (err) {
        logger.error('Function: [[%s]]. Error while fetching user from wallet address', funcName);
        logger.error('Error:', err);
        done(err);
        return;
      }

      if (!user) {
        logger.error('Function: [[%s]]. User with wallet address not found', funcName);
        err = new Error('Wallet address does not exist');
        done(err);
        return;
      }

      walletAddress = user.wallet_address;
      userId = user._id;
      // Amount sent by the user
      amtSentBtc = addressMap[walletAddress].value;
      logger.info('Function: [[%s]]. User\'s Email: [[%j]]', funcName, user.email);
      logger.debug('User:', user);
      done(null, user);
    }
  },
      function insertOrder(user, done) {
    let funcName = 'insertOrder';
    let min_order_amt_btc = constants.min_order_amt_btc;
    let lock_in_milliseconds = constants.lock_in_milliseconds;
    let status;
    if (amtSentBtc < min_order_amt_btc) {
      logger.error('Function: [[%s]]. Insufficient funds. \n' +
        'Amount sent (btc): [[%d]].', funcName, amtSentBtc);
      status = 'Insufficient Funds';
    } else {
      status = 'Pending';
    }

    /********************************** ASYNC PARALLEL START**************************************/
    async.parallel([
        function createOrder(callback) {
      let funcName = 'parallel:createOrder';
      let orderObj = {};          // Order object to be saved in db.
      let signupDate = user.timestamp;
      let email = user.email;
      let userId = user.userId;
      let walletAddress = user.wallet_address;
      let now = Date.now();

      orderObj.email = email;
      orderObj.signup_date = signupDate;
      orderObj.orderId = shortId.generate();
      orderObj.wallet_address = walletAddress;
      orderObj.user_btc_address = user.user_btc_address;
      orderObj.timestamp = now;
      orderObj.order_date = now;
      orderObj.status = status;
      orderObj.txId = txId;
      orderObj.userId = user._id;
      orderObj.btc = amtSentBtc;
      orderObj.lock_in = now + lock_in_milliseconds;

      logger.debug('Function: [[%s]]', funcName);
      logger.trace('Function: [[%s]]. Saving order obj:', funcName, orderObj);
      let order = new Order(orderObj);
      order.save(function (err, savedOrder) {
        if (err) {
          logger.error('Function: [[%s]]. Error while saving order with txid: [[%s]]', funcName, txId);
          logger.error('Error:', err);
          err.customType = 'ORDER_SAVE_FAILED';
          callback(err);
          return;
        }

        orderId = savedOrder._id;
        logger.info('Function: [[%s]]. Order successfully saved.', funcName);
        logger.debug('Function: [[%s]]. Saved order obj:', funcName, savedOrder);
        callback(null, savedOrder);
      });
    }
    ], function mainParallelCallback(err, results) {
      let funcName = 'mainParallelCallback';
      if (err) {
        logger.error('Function: [[%s]]', funcName);
        done(err);
        return;
      }

      logger.debug('Function: [[%s]]. Results', funcName, results);
      done(null, 'success');
    });
    /********************************** ASYNC PARALLEL END **************************************/
  }
  ], function mainCallback(err, result) {
    let funcName = 'mainCallback';
    if (err) {
      logger.error('Function: [[%s]]. Error:', funcName, err);
      return;
    }

    logger.debug('Function: [[%s]]. Result:', funcName, result);
  });
}


module.exports = webhook;

