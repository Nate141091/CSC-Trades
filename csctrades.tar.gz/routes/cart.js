/**
 * Created by miningforce.
 */
'use strict';

const constants = require('../config/constants');
const config = require('config');
const path = require('path');
const productCatalogue = constants.productCatalogue;
const util =  require(constants.util);
const auth = require(constants.authMiddleware);
const log4js = require('log4js');
const Cart = require(constants.cartModel);
const xhr = config.get('xhr');

// Load the logger for this file
const logger = log4js.getLogger('cart');

function register(app) {
  /*app.post('/add-to-cart', auth.xhrAuthMiddleware, function (req, res, next) {
    let route, xhr, userId, userCart, msgObj;
    let xhr = true;
    let productId = req.body.productId;
    let product = productCatalogue.productId;

    if (!product) {
      logger.error('Route: [[%s]]. Product id [[%s]] is invalid.', route, productId);
      util.response({ msg: '400', xhr: xhr }, req, res);
      return;
    }

    logger.info('Route: [[%s]]. Product Id: [[%s]]', route, productId);

    let keys = Object.keys(product);
    let cartObj = {
      userId: req.user._id,
      qty: 1
    };

    keys.forEach(function (each) {
      cartObj[each] = product[each];
    });
    let userCart = new Cart(cartObj);

    logger.debug('Route: [[%s]]. Saving user\'s cart: [[%j]]', route, userCart);
    userCart.save(function (err, result) {
      if (err) {
        logger.error('Route: [[%s]]. Error while saving the user\'s cart', route);
        logger.error('Error:', err);
        msgObj = {
          msg: 'GENERIC',
          xhr: xhr
        };

        util.response(msgObj, req, res);
        return;
      }

      logger.info('Route: [[%s]]. Email: [[%s]]. \nUser\'s cart successfully saved.', route, req.user.email);
      util.response({ msg: 'ADD_TO_CART_SUCCESS'}, req, res);
    });
  });*/

  app.post('/add-to-cart', auth.xhrAuthMiddleware, function (req, res, next) {
    let userId, userCart, msgObj;
    let route = 'POST /add-to-cart';
    let xhr = true;
    let productId = req.body.productId;
    let product = productCatalogue[productId];

    if (!product) {
      logger.error('Route: [[%s]]. Product id [[%s]] is invalid.', route, productId);
      util.response({ msg: '400', xhr: xhr }, req, res);
      return;
    }

    logger.info('Route: [[%s]]. Product Id: [[%s]]', route, productId);

    let keys = Object.keys(product);
    let cartObj = {
      userId: req.user._id,
      wallet_address: req.user.wallet_address,
      email: req.user.email,
      referrer: req.user.referrer,
      status: 'active',
      timestamp: Date.now(),
      $inc: { quantity: 1 }
    };

    keys.forEach(function (each) {
      cartObj[each] = product[each];
    });

    logger.debug('Route: [[%s]]. Saving user\'s cart: \n[[%j]]', route, cartObj);
    Cart.addToCart(cartObj, addToCartCB);

    function addToCartCB(err, result) {
      if (err) {
        logger.error('Route: [[%s]]. Error while saving the user\'s cart', route);
        logger.error('Error:', err);
        msgObj = {
          msg: 'GENERIC',
          xhr: xhr
        };

        util.response(msgObj, req, res);
        return;
      }

      logger.debug('Route: [[%s]]. Result: [[%j]]', route, result);
      logger.info('Route: [[%s]]. Email: [[%s]]. \nUser\'s cart successfully saved.', route, req.user.email);
      util.response({ msg: 'ADD_TO_CART_SUCCESS', xhr: xhr }, req, res);
    }
  });

  app.get('/cart', auth.authMiddleware, function (req, res, next) {
    let route = 'GET /cart';
    let userId = req.user._id;
    let objId = req.query.objId;
    let json = (req.query.json === 'true') ? true : false;
    let options = { userId: userId };
    let walletAddress = req.user.wallet_address;
    let balance = req.user.balance;

    if (objId) {
      options.objId = objId
    }

    logger.debug('Route: [[%s]]. Object id: [[%s]]. Json: [[%s]]', route, objId, json);
    Cart.getCart(options, getCartCB);

    function getCartCB(err, docs) {
      let funcName = 'getCartCB';
      if (err) {
        logger.error('Function: [[%s]]. Error while fethcing cart');
        logger.error('Error:', err);
        res.sendFile(path.join(constants.public, '500.html'));
        return;
      }

      logger.info('Function: [[%s]]. Docs length: [[%d]]', funcName, docs.length);
      logger.trace('Cart:', docs);

      if (json) {
        res.send(docs);
        return;
      }

      res.render('cart', { cart: docs, balance: balance, walletAddress: walletAddress });
    }
  });

  app.delete('/delete-cart-item', auth.xhrAuthMiddleware, function (req, res, next) {
    let route = 'DELETE /delete-cart-item';
    let xhr = true;
    let cartItemId = req.body.cartItemId;
    let userId = req.user._id;

    if (typeof cartItemId !== 'string' || cartItemId.length !== 24) {
      logger.error('Route: [[%s]]. Invalid cart item id [[%s]]', route, cartItemId);
      util.response({ msg: '400', xhr: xhr }, req, res);
      return;
    }

    Cart.deleteCartItem(cartItemId, userId, deleteCartItemCB);

    function deleteCartItemCB(err, doc) {
      let funcName = 'deleteCartItemCB';
      if (err) {
        logger.error('Function: [[%s]]. Error while deleting cart item [[%s]]', funcName, cartItemId);
        logger.error('Error:', err);
        util.response({ msg: 'GENERIC', xhr: xhr}, req, res);
        return;
      }

      if (!doc) {
        logger.error('Function: [[%s]]. Cart item not found.', funcName);
        util.response({ msg: '400', xhr: xhr }, req, res);
        return;
      }

      logger.debug('Function: [[%s]]. Cart item removed successfully', funcName);
      util.response({msg: 'CART_ITEM_DELETED_SUCCESSFULLY', xhr: xhr}, req, res);
    }

  });

  app.post('/cart/edit', auth.xhrAuthMiddleware, function (req, res, next) {
    let route = 'POST /cart/edit';
    let xhr = true;
    let cartItemId = req.body.cartItemId;
    let quantity = +req.body.quantity;
    let userId = req.user._id;

    if (typeof cartItemId !== 'string' || cartItemId.length !== 24) {
      logger.error('Route: [[%s]]. Invalid cart item id [[%s]]', route, cartItemId);
      util.response({ msg: '400', xhr: xhr }, req, res);
      return;
    }

    if (!util.isNumber(quantity) || quantity < 1) {
      logger.error('Route: [[%s]]. Invalid quantity: [[%d]]', route, quantity);
      util.response({ msg: '400', xhr: xhr }, req, res);
      return;
    }

    let options = {
      userId: userId,
      cartItemId: cartItemId,
      quantity: quantity
    };

    logger.info('Route: [[%s]]. Cart item id: [[%s]]. User Id: [[%s]]. Quantity: [[%d]]',
      route, cartItemId, userId, quantity);
    Cart.editCartItem(options, editCartItemCB);

    function editCartItemCB(err, result) {
      let funcName = 'editCartItemCB';
      if (err) {
        logger.error('Route: [[%s]]. Error while updating user\'s cart', route);
        logger.error('Error:', err);
        util.response({ msg: 'GENERIC', xhr: xhr }, req, res);
        return;
      }

      if (!result) {
        logger.error('Function: [[%s]]. Cart item not found.', funcName);
        util.response({ msg: '400', xhr: xhr }, req, res);
        return;
      }

      logger.debug('Route: [[%s]]. Function: [[%s]]. \nResult: [[%j]]', route, funcName, result);
      logger.info('Route: [[%s]]. Email: [[%s]]. Cart updated successfully.', route, req.user.email);
      util.response({ msg: 'CART_UPDATED_SUCCESSFULLY', xhr: xhr }, req, res);
    }
  });
}


module.exports = register;