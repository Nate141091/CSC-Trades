/**
 * Created by Mining force.
 */

'use strict';

const passport = require('passport');
const log4js = require('log4js');
const config = require('config');
const path = require('path');
const emailUtils = require('../utils/emailUtils');
const constants = require('../config/constants');
const auth = require(constants.authMiddleware);
const util = require(constants.util);

// Load the logger
const logger = log4js.getLogger('signin');

function login(app) {
  // Login needs to check for verified token, before letting the user log in
  app.post('/signin', function (req, res, next) {
    let route = 'POST /signin';
    logger.debug('Route: [[%s]].', route);
    if (!emailUtils.isValidEmail(req.body.email)) {
      res.sendFile(path.join(constants.public, '400.html'));
      return;
    }

    next();
  }, passport.authenticate('local', {
    successRedirect: '/login-success',
    failureRedirect: '/unauthorized'
  }));

  app.get('/login-success', auth.xhrAuthMiddleware, function (req, res) {
    if (req.user.isAdmin) {
      util.response({ msg: 'LOGIN_SUCCESS_ADMIN', xhr: true }, req, res);
      return;
    }

    util.response({ msg: 'LOGIN_SUCCESS', xhr: true }, req, res);
  });

  app.get('/unauthorized', function (req, res) {
    util.response({ msg: 'INVALID_USERNAME_PASSWORD', xhr: true }, req, res);
  });

  app.get('/logout', function (req, res) {
    if (req.user) {
      logger.debug('User: [[%s]]. Logged out', req.user.email);
    }

    req.logout();
    res.redirect('/');
  });

}

module.exports = login;