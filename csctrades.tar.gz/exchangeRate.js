/**
 * Created by Csctrades.
 */

'use strict';

const log4js = require('log4js');
const constants = require('./config/constants');
const request = require('request');
const altCoins = [
  'USDT_BTC',
  'USDT_XRP',
  'USDT_ETH',
  'USDT_LTC',
  'USDT_ZEC',
  'USDT_DASH',
  'USDT_ETC',
  'USDT_XMR',
  'BTC_XEM',
  'BTC_LSK'
];

// Load the logger
const logger = log4js.getLogger('exchangeRate');

function getAltCoinRates() {
  let funcName = 'getAltCoinRates';
  logger.info('Function: [[%s]]. Initialising cache for btc to usd rate', funcName);
  _updateCache();
  setInterval(_updateCache, 60000);

};

function _updateCache() {
  let funcName = '_updateCache';
  let cache = {};
  request(constants.poloniexApi, function (err, response, body) {
    if (err || (response && response.statusCode !== 200)) {
      logger.error('Function: [[%s]]. Error:', err, '\nStatus Code:',
        funcName, (response ? response.statusCode: null));
      logger.error('Function: [[%s]]. Failed to update cache. Cache not updated. ' + 
        'Retry in 1 min.');
      return;
    }

    body = JSON.parse(body);
    altCoins.forEach(function (item) {
      if (item === 'BTC_XEM' || item === 'BTC_LSK') {
        cache[item] = {
          last: +((body[item]["last"] * body.USDT_BTC.last).toFixed(2)),
          percentChange: +(Number(body[item]["percentChange"]).toFixed(4))
        };
        return;
      }

      cache[item] = {
        last: +(Number(body[item]["last"]).toFixed(2)),
        percentChange: +(Number(body[item]["percentChange"]).toFixed(4))
      }; 
    });

    logger.debug('Function: [[%s]]. Cache:', funcName, cache);
    logger.debug('Function: [[%s]]. Status code: [[%d]]', funcName, response.statusCode);
    // Update the btc cache with latest values.
    global.exchangeRate = cache;
    logger.info('Function: [[%s]]. Btc cache updated successfully.', funcName);

  });
}

module.exports = getAltCoinRates;

