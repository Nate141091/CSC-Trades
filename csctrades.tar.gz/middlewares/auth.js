/**
 * Created by Miningforce.
 */

'use strict';

const log4js = require('log4js');
const constants = require('../config/constants');
const path = require('path');
const util = require(constants.util);

// Load the logger for this file
const logger = log4js.getLogger('auth.js');
const auth = exports;

auth.authMiddleware = function authMiddleware(req, res, next) {
  let funcName = 'authMiddleware';
  let route = req.method + ' ' + req.path;
  logger.info('Middleware: [[%s]]. Authenticating for route: [[%s]]', funcName, route);

  if (!req.user) {
    logger.error('User not logged in.');
    res.redirect('/signin');
    return;
  }

  next();
};

auth.xhrAuthMiddleware = function xhrAuthMiddleware(req, res, next) {
  let funcName = 'xhrAuthMiddleware';
  let route = req.method + ' ' + req.path;
  logger.info('Middleware: [[%s]]. Authenticating for route: [[%s]]', funcName, route);

  if (!req.user) {
    logger.error('User not logged in.', route);
    util.response({ msg: 'UNAUTHORISED', xhr: true}, req, res);
    return;
  }

  next();
};

auth.adminAuth = function adminAuth(req, res, next) {
  let funcName = 'adminAuth';
  let route = req.method + ' ' + req.path;
  logger.info('Middleware: [[%s]]. Authenticating for route: [[%s]]', funcName, route);

  if (!req.user || !req.user.isAdmin) {
    logger.error('User not logged in/ Not an admin', route);
    res.sendFile(path.join(constants.public, '404.html'));
    return;
  }

  next();
}