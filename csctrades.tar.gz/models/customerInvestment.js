/**
 * Created by Mining force.
 */

'use strict';
const log4js = require('log4js');
const mongoose = require('mongoose');
const constants = require('../config/constants');
const assert = require('assert');
const Schema = mongoose.Schema;

// Load the logger for this file
const logger = log4js.getLogger('customerInvestment');

const CustomerInvestment = new Schema({
  total_investment: Number,
  total_investment_unit: String,
  type: String
});


CustomerInvestment.statics.incInvestment = function incInvestment(rawOpt, callback) {
  let funcName = 'incInvestment';
  let investment = rawOpt.investment;
  let type = rawOpt.type;
  assert(typeof investment === 'number' && Number.isFinite(investment) && investment > 0, 'Invalid investment');
  assert(type, 'Invalid type');
  logger.debug('Function: [[%s]]. Raw options: [[%j]]', funcName, rawOpt);

  let query = { type: type };
  let options = { multi: false , upsert: true, new: true};
  let update = {
    $inc: { total_investment: investment },
    type: type,
    total_investment_unit: constants.total_investment_unit
  };

  logger.trace('Query: [[%j]]. Update: [[%j]]', query, update);
  this.findOneAndUpdate(query, update, options, callback);
};

module.exports = mongoose.model('CustomerInvestment', CustomerInvestment);