/**
 * Created by Mining force.
 */

'use strict';
const log4js = require('log4js');
const mongoose = require('mongoose');
const Schema = mongoose.Schema;

// Load the logger for this file
const logger = log4js.getLogger('count');

const Count = new Schema({
  count: Number,
  type: String
});

Count.statics.getCounter = function getCounter(callback) {
  let funcName = 'getCounter';
  logger.debug('Function: [[%s]]', funcName);

  this.findOne({type: 'address_counter'}, function (err, countObj) {
    if (err) {
      logger.error('Function: [[%s]]. Error:', funcName, err);
      callback(err);
      return;
    }

    if (!countObj) {
      let errStr = 'No count object in mongodb.'
      logger.error(errStr);
      // todo: Is it necessary to kill the process ?
      process.exit(1);
    }

    logger.info('Derivation Counter object', countObj);
    let count = countObj.count;
    // Increment counter by 1 and save it for next time.
    ++countObj.count;

    countObj.save(function result(err, count) {
      if (err) {
        logger.error('Error:', err);
        return;
      }
      logger.info('Counter incremented successfully.');
      logger.trace('Saved Derivation Counter object:', count);
    });

    callback(null, count);
  });
};


module.exports = mongoose.model('Count', Count);