/**
 * Created by miningforce.
 */
'use strict';

const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const assert = require('assert');
const log4js = require('log4js');

// Load the logger
const logger = log4js.getLogger('models/referral');

const Referral = new Schema({
  referrer: String,                   // Index this field
  person_referred_username: String,
  person_referred_email: String,
  person_referred_country: String,
  person_referred_signup_date: Number,
  person_referred_orderid: String,
  hash_power_purchased: Number,
  hash_power_purchased_unit: String,
  affiliate_bonus: Number,
  purchase_date: Number
});

Referral.statics.getReferrals = function getReferrals(options, callback) {
  let funcName = 'getReferrals';
  let username = options.username;
  assert(username, 'Invalid referrer username');
  logger.debug('Function: [[%s]]. Options: [[%j]]', funcName, options);
  let query = { referrer: username };

  this.find(query).lean().exec(callback);
};


module.exports = mongoose.model('Referral', Referral);