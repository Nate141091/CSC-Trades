/**
 * Created by Mining Force.
 */

'use strict';

const log4js = require('log4js');
const mongoose = require('mongoose');
const Schema = mongoose.Schema;

// Load the logger
const logger = log4js.getLogger('wallet');

const Wallet = new Schema({
  index: Number,               // Index this field
  wallet_address: String
});

Wallet.statics.getAddressFromIndex = function getAddressFromIndex(index, callback) {
  let funcName = 'getAddressFromIndex';
  logger.info('Function: [[%s]]. Index: [[%d]]', funcName, index);

  this.findOne({index: index}).lean().exec(callback);
};

module.exports = mongoose.model('Wallet', Wallet);
