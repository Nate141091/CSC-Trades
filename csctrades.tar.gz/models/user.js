/**
 * Created by miningforce.
 */
'use strict';

const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const constants = require('../config/constants');
const util = require(constants.util);
const assert = require('assert');
const log4js = require('log4js');
const passportLocalMongooseEmail = require('passport-local-mongoose-email');

// Load the logger
const logger = log4js.getLogger('models/user');

const User = new Schema({
  total_investment: {type: Number, default: 0},
  total_investment_unit: {type: String, default: 'BTC'},
  email: String,                       // Create a index
  timestamp: Number,
  password: String,
  wallet_address_index: Number,
  wallet_address: String,              // Create a unique index
  user_btc_address: {type: String, default: null},
  resetPasswordToken: {type: String, default: null},
  resetPasswordExpires: { type: Number, default: null},
  isAdmin: Boolean
});

User.plugin(passportLocalMongooseEmail, {
  usernameField: 'email'
});

User.statics.isValidUser = function isValidUser(referrer, callback) {
  let fName = 'isValidUser';
  logger.debug('Function: [[%s]]. Referrer : [[%s]]', fName, referrer);

  this.findOne({username: referrer}, callback);
}

User.statics.updateTotalInvestment = function updateTotalInvestment(rawOpt, callback) {
  let funcName = 'updateTotalInvestment';
  let userId = rawOpt.userId;
  let investment = rawOpt.investment;
  let options = { multi: false , upsert: false, new: true};
  assert(userId, 'Invalid user id');
  assert(typeof investment === 'number' && Number.isFinite(investment) && investment > 0, 'Invalid investment');
  logger.debug('Function: [[%s]]. Raw options: [[%j]]', funcName, rawOpt);

  let query = { _id: userId };
  let update = {
    $inc: { total_investment: investment }
  };

  logger.trace('Query: [[%j]]. Update: [[%j]]', query, update);
  this.findOneAndUpdate(query, update, options, callback);
};

User.statics.updateReferralPower = function updateReferralPower(rawOpt, callback) {
  let funcName = 'updateReferralPower';
  let referrer = rawOpt.referrer;
  let hashPower = rawOpt.hashPower;
  let options = { multi: false , upsert: false, new: true};
  assert(typeof referrer, 'Invalid referrer');
  assert(typeof hashPower === 'number' && Number.isFinite(hashPower) && hashPower > 0, 'Invalid hash power');
  logger.debug('Function: [[%s]]. Raw options: [[%j]]', funcName, rawOpt);

  let query = { username: referrer };
  let update = {
    $inc: { total_referral_power: hashPower }
  };

  logger.trace('Query: [[%j]]. Update: [[%j]]', query, update);
  this.findOneAndUpdate(query, update, options, callback);
};

User.statics.getUserFromWalletAddress = function getUserFromWalletAddress(options, callback) {
  let funcName = 'getUserFromWalletAddress';
  let addresses = options.addresses;
  assert(Object.prototype.toString.call(addresses) === '[object Array]');
  logger.info('Function: [[%s]]. options:', funcName, options);
  let query = { wallet_address: { $in: addresses} };

  this.findOne(query, callback);
};

User.statics.fetchByUsername = function fetchByUsername(options, callback) {
  let funcName = 'fetchByUsername';
  let username = options.username;
  assert(username, 'Invalid username');
  logger.info('Function: [[%s]]. Options: [[%j]]', funcName, options);

  this.findOne({username: username}, callback);
};

User.statics.findByEmail = function findByEmail(options, callback) {
  let funcName = 'findByEmail';
  let email = options.email;
  assert(email, 'Invalid email');
  logger.info('Function: [[%s]]. Options: [[%j]]', funcName, options);

  this.findOne({email: email}, callback);
};

User.statics.updateBtcAddress = function updateBtcAddress(options, callback) {
  let funcName = 'updateBtcAddress';
  let userId = options.userId;
  let btcAddress = options.btcAddress;
  logger.info('Function: [[%s]]. Options: [[%j]]', funcName, options);
  let query = { _id: userId};
  let queryOpt = { new: true, upsert: false };
  let update = {
    $set: { user_btc_address: btcAddress }
  };

  this.findOneAndUpdate(query, update, queryOpt, callback);
};

User.statics.getAllUsers = function getAllUser(opt, callback) {
  let funcName = 'getAllUser';
  logger.info('Function: [[%s]]. Opt:', funcName, opt);

  this.find({}).lean().exec(callback);
};


module.exports = mongoose.model('User', User);