/**
 * Created by miningforce.
 */
'use strict';

const mongoose = require('mongoose');
const log4js = require('log4js');
const assert = require('assert');
const paginate = require('mongoose-range-paginate');
const Schema = mongoose.Schema;
const constants = require('../config/constants');
const pagesize = constants.pagesize;

// Load the logger for this file
const logger = log4js.getLogger('models/cart');

const Cart = new Schema({
  status: String,
  txId: String,                           // Index this field
  email: String,
  referrer: Schema.Types.ObjectId,
  userId: Schema.Types.ObjectId,          // Index this field for getCart functionality.
  wallet_address: String,                 // Index this field
  timestamp: Number,
  productId: Schema.Types.ObjectId,
  title: String,
  price: Number,
  currency: String,
  hash_power: Number,
  hash_power_unit: String,
  quantity: Number
});

Cart.statics.addToCart = function addToCart(cartObj, callback) {
  let funcName = 'addToCart';
  assert(cartObj.userId, 'invalid userid');
  assert(typeof cartObj.productId === 'string');
  logger.debug('Function: [[%s]]. Cart obj: [[%j]]', funcName, cartObj);
  let query = {
    userId: cartObj.userId,
    productId: cartObj.productId
  };

  let options = {
    new: true,
    upsert: true
  };

  logger.info('Query: [[%j]]. Options: [[%j]]', query, options);
  this.findOneAndUpdate(query, cartObj, options, callback);
};

Cart.statics.editCartItem = function editCartItem(options, callback) {
  let funcName = 'editCartItem';
  let cartItemId = options.cartItemId;
  let userId = options.userId;
  assert(typeof cartItemId === 'string' && cartItemId.length !== 0, 'Invalid cart item id');
  assert(userId, 'Invalid user id');
  logger.debug('Function: [[%s]]. Options: [[%j]]', funcName, options);

  let query = {
    userId: userId,
    _id: cartItemId
  };
  let update = {
    $set: {
      quantity: options.quantity,
      timestamp: Date.now()
    }
  };
  let queryOptions = {
    new: true,
    upsert: false
  };

  logger.info('Query: [[%j]]. Update: [[%j]]. Query Options: [[%j]]', query, update, queryOptions);
  this.findOneAndUpdate(query, update, queryOptions, callback);
};

Cart.statics.getCart = function getCart(options, callback) {
  let funcName = 'getCart';
  let userId = options.userId;
  let addresses = options.addresses;
  let rawQuery;
  let paginationOpt = {
    limit: pagesize
  };
  assert(userId || addresses, 'Invalid user id or wallet address specified');
  if (addresses) {
    assert(Object.prototype.toString.call(addresses));
  }

  logger.debug('Function: [[%s]]. userId: [[%s]]. addresses [[%j]]', funcName, userId, addresses);
  rawQuery = options.addresses
    ? { wallet_address: { $in: addresses }, status: 'active'}
    : { userId: userId, status: 'active' };

  if (options.objId) {
    paginationOpt.startId = options.objId;
  }

  let query = this.find(rawQuery);
  logger.info('Query: [[%j]]. Pagination options: [[%j]]', rawQuery, paginationOpt);
  paginate(query, paginationOpt).lean().exec(callback);
};

Cart.statics.deleteCartItem = function deleteCartItem(objId, userId, callback) {
  let funcName = 'deleteCartItem';
  logger.debug('Function: [[%s]]. Object Id: [[%s]]. User Id: [[%s]]', funcName, objId, userId);

  let query = {
    _id: objId,
    userId: userId,
    status: 'active'
  };
  let options = { passRawResult: false};

  logger.debug('Query: [[%j]]', query);
  this.findOneAndRemove(query, options, callback);
};

Cart.statics.clearCart = function clearCart(options, callback) {
  let funcName = 'clearCart';
  let txId = options.txId;
  let status = options.status;
  assert(txId, 'Invalid transaction id');
  assert((typeof status === 'string' && status.length > 0), 'Invalid status');
  logger.info('Function: [[%s]]. Options:', funcName, options);
  let query = {
    txId: txId,
    status: 'confirmed'
  };

  logger.debug('Function: [[%s]]. Query: [[%j]]', funcName, query);
  this.find(query).remove().exec(callback);
};

Cart.statics.updateStatus = function updateStatus(rawOpt, callback) {
  let funcName = 'updateStatus';
  let userId = rawOpt.userId;
  let status = rawOpt.rollback === true ? 'active' : 'junk';
  assert(userId, 'Invalid user id');
  logger.debug('Function: [[%s]]. Raw options: [[%j]]', funcName, rawOpt);
  let query = { userId: userId };
  let update = { $set: {status: status} };
  let options = { multi: true , upsert: false};

  logger.trace('Query: [[%j]]. Update: [[%j]]', query, update);
  this.update(query, update, options, callback)
};

Cart.statics.updateCart = function updateCart(rawOpt, callback) {
  let funcName = 'updateCart';
  let statusFrom = rawOpt.statusFrom;
  let statusTo = rawOpt.statusTo;
  let txId = rawOpt.txId;
  let walletAddress = rawOpt.walletAddress;
  assert(statusFrom, 'Invalid old status');
  assert(statusTo, 'Invalid new status');
  logger.debug('Function: [[%s]]. Raw options:', funcName, rawOpt);
  let query = { wallet_address: walletAddress, status: statusFrom };
  let update = { $set: {status: statusTo, txId: txId} };
  let options = { multi: true , upsert: false};

  logger.trace('Query: [[%j]]. Update: [[%j]]', query, update);
  this.update(query, update, options, callback);
};

Cart.statics.updateCartFromTxId = function updateCartFromTxId(rawOpt, callback) {
  let funcName = 'updateCartFromTxId';
  let statusFrom = rawOpt.statusFrom;
  let statusTo = rawOpt.statusTo;
  let txId = rawOpt.txId;
  assert(txId, 'Invalid transaction id');
  assert(statusTo, 'Invalid statusTo');
  assert(statusFrom, 'Invalid statusFrom');
  logger.debug('Function: [[%s]]. Raw options:', funcName, rawOpt);

  let query = {txId: txId, status: statusFrom};
  let update = { $set: { status: statusTo, timestamp: Date.now() } };
  let options = { multi: true , upsert: false};

  logger.trace('Query: [[%j]]. Update: [[%j]]', query, update);
  this.update(query, update, options, callback);
};


module.exports = mongoose.model('Cart', Cart);