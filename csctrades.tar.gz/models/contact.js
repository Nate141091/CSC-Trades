/**
 * Created by Csctrades.
 */

'use strict';
const log4js = require('log4js');
const mongoose = require('mongoose');
const Schema = mongoose.Schema;

// Load the logger for this file
const logger = log4js.getLogger('contact');

const Contact = new Schema({
  name: String,
  email: String,
  message: String
});

Contact.statics.getContacts = function getContacts(opt, callback) {
  let funcName = 'getContacts';
  logger.info('Function: [[%s]]. Options:', funcName, opt);

  this.find({}).lean().exec(callback);
};

module.exports = mongoose.model('Contact', Contact);