/**
 * Created by miningforce.
 */
'use strict';

const mongoose = require('mongoose');
const log4js = require('log4js');
const assert = require('assert');
const paginate = require('mongoose-range-paginate');
const constants = require('../config/constants');
const pageSize = constants.pageSize;
const util = require(constants.util);
const maxPageSize = constants.maxPageSize;
const one_day_milliseconds = constants.one_day_milliseconds;
const Schema = mongoose.Schema;

// Load the logger
const logger = log4js.getLogger('models/order');

const Order = new Schema({
  txId: String,                      // Index this field
  timestamp: Number,
  order_date: Number,
  orderId: String,                   // Index this field
  btc: Number,
  email: String,
  userId: Schema.Types.ObjectId,     // Index this field
  wallet_address: String,
  user_btc_address: String,
  status: String,
  lock_in: Number,
  signup_date: Number
});

Order.statics.removeTx = function removeTx(txId, callback) {
  let funcName = 'removeTx';
  logger.debug('Function: [[%s]]. Transaction id: [[%s]]', funcName, txId);

  let query = {
    _id: txId
  };
  let options = { passRawResult: false};

  logger.debug('Query: [[%j]]', query);
  this.findOneAndRemove(query, options, callback);
};

Order.statics.getOrders = function getOrders(options, callback) {
  let funcName = 'getOrders';
  let userId = options.userId;
  let statuses = options.statuses;
  let now = options.now;
  let limit = !options.limit ? maxPageSize: options.limit;
  let startId = options.startId;
  let startKey = options.startKey;
  if (statuses) {
    assert(Object.prototype.toString.call(statuses) === '[object Array]', 'Invalid statuses');
  }

  if (now) {
    assert(util.isNumber(now) && limit >= 0, 'Invalid timestamp `now`');
  }

  if (limit) {
    assert(util.isNumber(limit) && limit >= 0, 'Invalid page size');
  }

  logger.debug('Function: [[%s]]. Options: [[%j]]', funcName, options);
  let rawQuery = {};
  // todo remove comment
  // let pageOpt;
  // todo delete this
  let pageOpt = { limit: limit };
  /*if (limit < 10) {
    pageOpt.limit = pageSize;
  } else if (limit > maxPageSize) { // If limit is greater than max page size then set it to max page size.
    pageOpt.limit = maxPageSize;
  } else {
    pageOpt.limit = limit;
  }

  if (startId) {
    pageOpt.startId = startId;
  }

  if (startKey) {
    pageOpt.startKey = startKey;
  }*/

  if (statuses) {
    rawQuery.status = { $in: statuses };
  }

  if (userId) {
    rawQuery.userId = userId;
  }

  if (now) {
    rawQuery.timestamp = { $lt: now - one_day_milliseconds };
  }

  let query = this.find(rawQuery);
  logger.debug('Query: [[%j]]. Pagination options: [[%j]]', rawQuery, pageOpt);
  paginate(query, pageOpt).lean().exec(callback);
};

Order.statics.updateStatus = function updateStatus(rawOpt, callback){
  let funcName = 'updateStatus';
  let txId = rawOpt.txId;
  let orderId = rawOpt.orderId;
  let statusFrom = rawOpt.statusFrom;
  let statusTo = rawOpt.statusTo;
  // todo delete this
  // let now = Date.now() + 7948800000;
  // todo remove comment
  let now = Date.now();
  assert(txId || orderId, 'Invalid transaction id');
  assert(statusFrom, 'Invalid statusFrom');
  assert(statusTo, 'Invalid statusTo');
  logger.debug('Function: [[%s]]. Raw options: [[%j]]', funcName, rawOpt);

  let query = { status: statusFrom};
  let update = { $set: {status: statusTo, timestamp: now }};
  let options = { multi: false , upsert: false, new: true};
  if (txId) {
    query.txId = txId;
  } else if (orderId) {
    query.orderId = orderId;
    query.lock_in = { $lt: now };
  }

  logger.debug('Query: [[%j]]. Update: [[%j]]', query, update);
  this.findOneAndUpdate(query, update, options, callback);
};

Order.statics.getStatusFromTxId = function getStatusFromTxId(rawOpt, callback) {
  let funcName = 'getStatusFromTxId';
  let txId = rawOpt.txId;
  assert(txId, 'Invalid tx id');
  logger.info('Function: [[%s]]. Transaction id: [[%s]]', funcName, txId);
  let query = { txId: txId };
  let fields = '-products';

  logger.debug('Query: [[%j]]', query);
  this.findOne(query, fields, callback);
};

Order.statics.getTotalOrders = function getTotalOrders(rawOpt, callback) {
  let funcName = 'getTotalOrders';
  let userId = rawOpt.userId;
  assert(userId, 'Invalid user id');
  logger.info('Function: [[%s]]. Raw options: [[%j]]', funcName, rawOpt);
  let query = { userId: userId };

  logger.debug('Query: [[%j]]', query);
  this.count(query, callback);
};

Order.statics.updateStatusByOrderIds = function updateStatusByOrderIds(rawOpt, callback) {
  let funcName = 'updateStatusByOrderIds';
  let orderIds = rawOpt.orderIds;
  assert(Object.prototype.toString.call(orderIds) === '[object Array]');
  logger.debug('Function: [[%s]]. Options:', funcName, rawOpt);

  let query = { orderId: { $in: orderIds }};
  let update = { $set: { status: 'Withdrawn'}};
  let options = { upsert: false, multi: true };

  logger.debug('Query: [[%j]]. Update: [[%j]]', query, update);
  this.update(query, update, options, callback);
};

Order.statics.getTx = function getTx(opt, callback) {
  let funcName = 'getTx';
  let txId = opt.txId;
  assert(txId, 'Invalid txId');
  logger.info('Function: [[%s]]. Options: [[%j]]', funcName, opt);

  this.findOne({txId: txId}).lean().exec(callback);
};

module.exports = mongoose.model('Order', Order);
