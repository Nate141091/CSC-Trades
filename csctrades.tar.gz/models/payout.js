/**
 * Created by miningforce.
 */

'use strict';

const mongoose = require('mongoose');
const log4js = require('log4js');
const assert = require('assert');
const Schema = mongoose.Schema;

// Load the logger
const logger = log4js.getLogger('payout');

const Payout = new Schema({
  timestamp: Number,
  orderId: String,
  order_date: Number,
  order_amt_btc: Number,
  daily_payout_btc: Number,
  email: String,                      // Index this field
  userId: Schema.Types.ObjectId,
  wallet_address: String,
  user_btc_address: String,
  signup_date: Number
});

Payout.statics.getPayouts = function getPayouts(opt, callback) {
  let funcName = 'getPayouts';
  let email = opt.email;
  logger.debug('Function: [[%s]]. Options:', funcName, opt);
  let query = {};
  if (email) {
    query.email = email;
  }

  logger.info('Query:', query);
  this.find(query).lean().exec(callback);
};

Payout.statics.getTotalEarned = function getTotalEarned(opt, callback) {
  let funcName = 'getTotalEarned';
  let email = opt.email;
  assert(email, 'Email required');
  logger.info('Function: [[%s]]. Options:', funcName, opt);

  this.aggregate({$match: { email: email}}, {$group:{_id: null, totalEarned: {$sum: '$daily_payout_btc'}}}, callback);
};


module.exports = mongoose.model('Payout', Payout);
