/**
 * Created by Csctrades.
 */

'use strict';

const log4js = require('log4js');
const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const assert = require('assert');

// Load the logger
const logger = log4js.getLogger('subscription');

const Subscription = new Schema({
  email: String
});

Subscription.statics.viewSubscriptions = function viewSubscriptions(options, callback) {
  let funcName = 'viewSubscriptions';
  logger.info('Function: [[%s]]. Options: [[%s]]', funcName, options);

  this.find({}).lean().exec(callback);
};

module.exports = mongoose.model('Subscription', Subscription);