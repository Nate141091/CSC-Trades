/**
 * Created by Mining force.
*/

'use strict';

const log4js = require('log4js');
const mongoUtils = exports;

// Load the logger
const logger = log4js.getLogger('log4js');

mongoUtils.resetPassword = function resetPassword(account, password, cb) {
  logger.info('In resetPassword.');
  if (!account || !password) {
    logger.error('Function Name: resetPassword. Invalid arguments');
    cb(new Error('Invalid arguments'));
  }

  account.setPassword(password, cb);
};