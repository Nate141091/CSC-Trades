/**
 * Created by Respectonomy.
 */

'use strict';

const assert = require('assert');
const config = require('config');
const xhr = config.get('xhr');
const log4js = require('log4js');
// Load the logger
const logger = log4js.getLogger('util');
let util = exports;

/**
 * Max safe integer (53 bits).
 * @const {Number}
 * @default
 */
util.MAX_SAFE_INTEGER = 0x1fffffffffffff;

/**
 * Test whether a number is below MAX_SAFE_INTEGER.
 * @param {Number} value
 * @returns {Boolean}
 */
util.isSafeInteger = function isSafeInteger(value) {
  if (Number.isSafeInteger)
    return Number.isSafeInteger(value);
  return Math.abs(value) <= util.MAX_SAFE_INTEGER;
};

/**
 * Test whether a number is Number,
 * finite, and below MAX_SAFE_INTEGER.
 * @param {Number?} value
 * @returns {Boolean}
 */
util.isNumber = function isNumber(value) {
  return typeof value === 'number'
    && isFinite(value)
    && util.isSafeInteger(value);
};

util.response = function response(msgObj, req, res) {
  let fName = 'response';
  logger.debug('Function: [[%s]]. Message Object: [[%j]]', fName, msgObj);
  assert(typeof msgObj.msg === 'string');

  let message = msgObj.msg;
  if (msgObj.xhr === true) {
    _xhrResponse(message, req, res);
    return;
  }

  _normalResponse(message, req, res);
}

function _xhrResponse(msg, req, res) {
  let fName = '_xhrResponse';
  logger.info('Function: [[%s]]. Message: [[%s]]', fName, msg);
  logger.debug('Sending response: [[%j]]', xhr[msg]);
  res.status(200).send(xhr[msg]);
}

function _normalResponse(msg, req, res) {
  let fName = '_normalResponse';
  logger.info('Function: [[%s]]. Message: [[%s]]', fName, msg);
  // todo send some template
  // res.render('', { message: renderMsg[message]});
  res.send('you must be signed in page.');
}

// todo delete this
function _normalResponse1(msg, template, req, res) {
  let fName = '_normalResponse';
  logger.info('Function: [[%s]]. Message: [[%s]]. Template: [[%s]]', fName, msg, template);
  res.render(template, { message: renderMsg[message]});
}
