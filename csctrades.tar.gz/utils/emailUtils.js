/**
 * Created by hitibits on 2/2/17.
 */

'use strict';
const helper = require('sendgrid').mail;
const constants = require('../config/constants');
const config = require('config');
const SENDGRID_API_KEY = config.get('SENDGRID_API_KEY');
const log4js = require('log4js');
const email = exports;

// Load the logger
const logger = log4js.getLogger('emailUtils');

email.isValidEmail = function isValidEmail(email) {
  let reg = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  return reg.test(email);
};

email.sendMail = function (from, to, subject, htmlContent, cb) {
  logger.debug('Function: sendMail. From: [[%s]]. To: [[%s]]. subject: [[%s]]', from, to, subject);

  let from_email = new helper.Email(from, 'CSC Trades');
  let to_email = new helper.Email(to);
  let content = new helper.Content("text/html", htmlContent);
  let mail = new helper.Mail(from_email, subject, to_email, content);

  let sg = require('sendgrid')(SENDGRID_API_KEY);
  let request = sg.emptyRequest({
    method: 'POST',
    path: '/v3/mail/send',
    body: mail.toJSON()
  });

  sg.API(request, cb);
};

email.duplicateKeyAlert = function (timestamp, email, callback) {
  let funcName = 'duplicateKeyAlert';
  let from = constants.miningforce_info_email;
  let to = constants.miningforce_info_email;
  let subject = 'Duplicate key collision for wallet_address';
  let content = '<div align="left" sytle="font-size:15px; padding: 15px;">Hi,<br>' +
    '<br> Date: ' + timestamp + '<br>' + 'User\'s email: ' + email + ' <br> Duplicate wallet address assigned.'
    '<br>Regards, <br>MiningForce Server' +
    '</div><div style="font-size: 13px;">Mining Force &copy; 2017.</div>';

  this.sendMail(from, to, subject, content, sendMailCB);

  function sendMailCB(err, response) {
    logger.info('Function: sendMailCB');
    if (err) {
      logger.error('Mining force could not be alerted. \nMail not sent');
      logger.error('Error: [[%s]]', JSON.stringify(err));
      return;
    }

    logger.info('Sendgrid status code: [[%d]]',response.statusCode);
    logger.info('Sendgrid response body: [[%j]]', response.body);
    logger.info('Sendgrid headers: [[%j]]', response.headers);

    if (response.statusCode !== 202) {
      logger.error('Sendgrid status code: [[%d]]', response.statusCode);
      logger.error('Something happened! Mail could not be sent');
      return;
    }

    logger.info('Mail successfully sent to Mining force');
  }
};


