/**
 * Created by Mining Force.
 */

'use strict';

const log4js = require('log4js');
const async = require('async');
const constants = require('../config/constants');
const Count = require(constants.countModel);
const Wallet = require(constants.walletModel);

// Load the logger
const logger = log4js.getLogger('btc');

exports.getWalletAddress = function getWalletAddress(callback) {
  let funcName = 'getWalletAddress';
  logger.info('Function: [[%s]]', funcName);

  async.waterfall([
      function getCounter(done) {
    let funcName = 'getCounter';
    logger.info('Function: [[%s]]', funcName);
    Count.getCounter(function getCounterCB(err, count) {
    let funcName = 'getCounterCB';
    if (err) {
      logger.error('Function: [[%s]]. Error while fetching counter.', funcName);
      logger.error('Error:', err);
      done(err);
      return;
    }

    logger.info('Function: [[%s]]. Count: [[%d]]', funcName, count);
    done(null, count);
  });
  },
      function getAddress(count, done) {
    let funcName = 'getAddress';
    logger.info('Function: [[%s]]. Count: [[%d]]', funcName, count);

    Wallet.getAddressFromIndex(count, getAddressFromIndexCB);
    function getAddressFromIndexCB(err, walletObj) {
      let funcName = 'getAddressFromIndexCB';
      if (err) {
        logger.error('Function: [[%s]]. Error while fetching address from index', funcName);
        logger.error('Error:', err);
        done(err);
        return;
      }

      logger.debug('Function: [[%s]]. Wallet obj [[%j]]', funcName, walletObj);
      done(null, walletObj);
    }
  }], function mainCallback(err, result) {
    callback(err, result);
  });

};
