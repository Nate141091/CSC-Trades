(function($){

$(document).ready(function ($) {


    tickerdata();
    currtickerdata();
    window.setInterval(function(){tickerdata();},60000);
    window.setInterval(function(){currtickerdata();},3600000);

     // jQuery('#map').CustomMap();


     ////------- Testimonials Carousel

    // var testimonial = $(".testimonial-wrapper");
    // testimonial.owlCarousel({
    //     pagination: false,
    //     navigation : true,
    //     slideSpeed : 1000,
    //     stopOnHover: true,
    //     autoPlay: 3000,
    //     singleItem: true,
    //     transitionStyle : "fade",
    //     navigationText: ['<i class="fa fa-chevron-left"></i>', '<i class="fa fa-chevron-right"></i>']
    // });

    /*----------------------------------------------------*/
	/*	Nav Menu & Search
	/*----------------------------------------------------*/

	$(".nav > li:has(ul)").addClass("drop");
	$(".nav > li.drop > ul").addClass("dropdown");
	$(".nav > li.drop > ul.dropdown ul").addClass("sup-dropdown");





    /*---------------------------------------------------*/
    /* Progress Bar
    /*---------------------------------------------------*/
    $(document).ready(function($) {
	"use strict";



        $('.skill-shortcode').appear(function() {
            $('.progress').each(function(){
                $('.progress-bar').css('width',  function(){ return ($(this).attr('data-percentage')+'%')});
            });
        },{accY: -100});


    });


    /*--------------------------------------------------*/
    /* Counter*/
    /*--------------------------------------------------*/
    $('.timer').countTo();

    $('.counter-item').appear(function() {
        $('.timer').countTo();
    },{accY: -100});



    var timer = !1;
    _Ticker = $("#T1").newsTicker();
    _Ticker2 = $("#T2").newsTicker();
    // _Ticker.on("mouseenter",function(){
    //     var __self = this;
    //     // timer = setTimeout(function(){
    //         __self.pauseTicker();
    //     // },200);
    // });
    // _Ticker.on("mouseleave",function(){
    //     // clearTimeout(timer);
    //     // if(!timer) return !1;
    //     this.startTicker();
    // });
});

}(jQuery));

function tickerdata(){
    // console.log('-----------');
    $.get("/rates").done(function(data){
        // console.log(data);
        $('.btc-price').html('<i class="fa fa-dollar"></i> '+data.USDT_BTC.last.toFixed(2));
        if(data.USDT_BTC.percentChange<0)
        {
            $('.btc-percent').addClass("down");
            $('.btc-percent').removeClass("up");
            $('.btc-percent').html('<i class="fa fa-caret-down"></i> ' + ((data.USDT_BTC.percentChange*-1).toFixed(2)));
        }
        else
        {
            $('.btc-percent').addClass("up");
            $('.btc-percent').removeClass("down");
            $('.btc-percent').html('<i class="fa fa-caret-up"></i> ' + data.USDT_BTC.percentChange.toFixed(2));
        }

        $('.xrp-price').html('<i class="fa fa-dollar"></i> '+data.USDT_XRP.last.toFixed(2));
        if(data.USDT_XRP.percentChange<0)
        {
            $('.xrp-percent').addClass("down");
            $('.xrp-percent').removeClass("up");
            $('.xrp-percent').html('<i class="fa fa-caret-down"></i> ' + ((data.USDT_XRP.percentChange*-1).toFixed(2)));
        }
        else
        {
            $('.xrp-percent').addClass("up");
            $('.xrp-percent').removeClass("down");
            $('.xrp-percent').html('<i class="fa fa-caret-up"></i> ' + data.USDT_XRP.percentChange.toFixed(2));
        }

        $('.eth-price').html('<i class="fa fa-dollar"></i> '+data.USDT_ETH.last.toFixed(2));
        if(data.USDT_ETH.percentChange<0)
        {
            $('.eth-percent').addClass("down");
            $('.eth-percent').removeClass("up");
            $('.eth-percent').html('<i class="fa fa-caret-down"></i> ' + ((data.USDT_ETH.percentChange*-1).toFixed(2)));
        }
        else
        {
            $('.eth-percent').addClass("up");
            $('.eth-percent').removeClass("down");
            $('.eth-percent').html('<i class="fa fa-caret-up"></i> ' + data.USDT_ETH.percentChange.toFixed(2));
        }

        $('.ltc-price').html('<i class="fa fa-dollar"></i> '+data.USDT_LTC.last.toFixed(2));
        if(data.USDT_LTC.percentChange<0)
        {
            $('.ltc-percent').addClass("down");
            $('.ltc-percent').removeClass("up");
            $('.ltc-percent').html('<i class="fa fa-caret-down"></i> ' + ((data.USDT_LTC.percentChange*-1).toFixed(2)));
        }
        else
        {
            $('.ltc-percent').addClass("up");
            $('.ltc-percent').removeClass("down");
            $('.ltc-percent').html('<i class="fa fa-caret-up"></i> ' + data.USDT_LTC.percentChange.toFixed(2));
        }

        $('.zec-price').html('<i class="fa fa-dollar"></i> '+data.USDT_ZEC.last.toFixed(2));
        if(data.USDT_ZEC.percentChange<0)
        {
            $('.zec-percent').addClass("down");
            $('.zec-percent').removeClass("up");
            $('.zec-percent').html('<i class="fa fa-caret-down"></i> ' + ((data.USDT_ZEC.percentChange*-1). toFixed(2)));
        }
        else
        {
            $('.zec-percent').addClass("up");
            $('.zec-percent').removeClass("down");
            $('.zec-percent').html('<i class="fa fa-caret-up"></i> ' + data.USDT_ZEC.percentChange.toFixed(2));
        }

        $('.dash-price').html('<i class="fa fa-dollar"></i> '+data.USDT_DASH.last.toFixed(2));
        if(data.USDT_DASH.percentChange<0)
        {
            $('.dash-percent').addClass("down");
            $('.dash-percent').removeClass("up");
            $('.dash-percent').html('<i class="fa fa-caret-down"></i> ' + ((data.USDT_DASH.percentChange*-1).toFixed(2)));
        }
        else
        {
            $('.dash-percent').addClass("up");
            $('.dash-percent').removeClass("down");
            $('.dash-percent').html('<i class="fa fa-caret-up"></i> ' + data.USDT_DASH.percentChange.toFixed(2));
        }

        $('.etc-price').html('<i class="fa fa-dollar"></i> '+data.USDT_ETC.last.toFixed(2));
        if(data.USDT_ETC.percentChange<0)
        {
            $('.etc-percent').addClass("down");
            $('.etc-percent').removeClass("up");
            $('.etc-percent').html('<i class="fa fa-caret-down"></i> ' + ((data.USDT_ETC.percentChange*-1).toFixed(2)));
        }
        else
        {
            $('.etc-percent').addClass("up");
            $('.etc-percent').removeClass("down");
            $('.etc-percent').html('<i class="fa fa-caret-up"></i> ' + data.USDT_ETC.percentChange.toFixed(2));
        }

        $('.xmr-price').html('<i class="fa fa-dollar"></i> '+data.USDT_XMR.last.toFixed(2));
        if(data.USDT_XMR.percentChange<0)
        {
            $('.xmr-percent').addClass("down");
            $('.xmr-percent').removeClass("up");
            $('.xmr-percent').html('<i class="fa fa-caret-down"></i> ' + ((data.USDT_XMR.percentChange*-1).toFixed(2)));
        }
        else
        {
            $('.xmr-percent').addClass("up");
            $('.xmr-percent').removeClass("down");
            $('.xmr-percent').html('<i class="fa fa-caret-up"></i> ' + data.USDT_XMR.percentChange.toFixed(2));
        }

        $('.xem-price').html('<i class="fa fa-dollar"></i> '+data.BTC_XEM.last.toFixed(2));
        if(data.BTC_XEM.percentChange<0)
        {
            $('.xem-percent').addClass("down");
            $('.xem-percent').removeClass("up");
            $('.xem-percent').html('<i class="fa fa-caret-down"></i> ' + ((data.BTC_XEM.percentChange*-1).toFixed(2)));
        }
        else
        {
            $('.xem-percent').addClass("up");
            $('.xem-percent').removeClass("down");
            $('.xem-percent').html('<i class="fa fa-caret-up"></i> ' + data.BTC_XEM.percentChange.toFixed(2));
        }

        $('.lsk-price').html('<i class="fa fa-dollar"></i> '+data.BTC_LSK.last.toFixed(2));
        if(data.BTC_LSK.percentChange<0)
        {
            $('.lsk-percent').addClass("down");
            $('.lsk-percent').removeClass("up");
            $('.lsk-percent').html('<i class="fa fa-caret-down"></i> ' + ((data.BTC_LSK.percentChange*-1).toFixed(2)));
        }
        else
        {
            $('.lsk-percent').addClass("up");
            $('.lsk-percent').removeClass("down");
            $('.lsk-percent').html('<i class="fa fa-caret-up"></i> ' + data.BTC_LSK.percentChange.toFixed(2));
        }

    });

}


function currtickerdata() {
    console.log();
    $.get("/currency-rates").done(function(data){
        console.log(data);
        $('.EUR-price').html(data.USDEUR.toFixed(4));
        $('.GBP-price').html(data.USDGBP.toFixed(4));
        $('.CHF-price').html(data.USDCHF.toFixed(4));
        $('.AUD-price').html(data.USDAUD.toFixed(4));
        $('.JPY-price').html(data.USDJPY.toFixed(4));
        $('.CAD-price').html(data.USDCAD.toFixed(4));
        $('.HKD-price').html(data.USDHKD.toFixed(4));
        $('.NZD-price').html(data.USDNZD.toFixed(4));
        $('.SGD-price').html(data.USDSGD.toFixed(4));
        $('.RUB-price').html(data.USDRUB.toFixed(4));

    });

}
