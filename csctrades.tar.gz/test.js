'use strict';

const mongoose = require('mongoose');
const Schema = mongoose.Schema;
mongoose.connect('mongodb://localhost/forum2');

var Topic = new Schema({
  topic: String,
  comments: [{com: Number}]
});

Topic = mongoose.model('Topic', Topic);
Topic.update({},
  { $pull: { 'comments': {_id:'58ad4a2cff23091ae25b10d4' }} }, callback);


/*Topic.findOneAndUpdate({topic: 'general'}, {$push: {comments: {com: 52}}},{upsert: false, new: true}, callback);*/
function callback(err, result) {
  console.log('Function: callback');
  if (err) {
    console.log('err', err);
  }

  console.log('-----------', result);
}

/*Topic.findOneAndUpdate({topic: 'general'}, {"comments" : {"$slice" : [23, 10]}}, {upsert: false, new: true}, callback);
function callback(err, result) {
  console.log('Function: callback');
  if (err) {
    console.log('err', err);
  }

  console.log('-----------', result);
}*/



// db.topics.insert({topic:"general",comments:[{com:1},{com:2},{com:3},{com:4},{com:5},{com:6},{com:7},{com:8},{com:9},{com:10},{com:11},{com:12},{com:13},{com:14},{com:15},{com:16},{com:17},{com:18},{com:19},{com:20},{com:21},{com:22},{com:23},{com:24},{com:25},{com:26},{com:27},{com:28},{com:29},{com:30},{com:31},{com:32},{com:33},{com:34},{com:35},{com:36},{com:37},{com:38},{com:39},{com:40},{com:41},{com:42},{com:43},{com:44},{com:45},{com:46},{com:47},{com:48},{com:49},{com:50}]});


/*function encrypt(text){
  console.log('Function: encrypt. Text to encrypt: [[%s]]', text);
  var cipher = crypto.createCipher('aes-256-ctr','l6F7Tfex')
  var crypted = cipher.update(text,'utf8','hex')
  crypted += cipher.final('hex');
  console.log('After encrypting: [[%s]]', crypted);
  return crypted;
}
 
function decrypt(text){
  console.log('Function: decrypt. Text to decrypt: [[%s]]', text);
  var decipher = crypto.createDecipher('aes-256-ctr','l6F7Tfex')
  var dec = decipher.update(text,'hex','utf8')
  dec += decipher.final('utf8');
  console.log('After decrypting: [[%s]]', dec);
  return dec;
}*/


/*
Query to get max time:
db.topics.aggregate({$project:{'comments.time':1}},{$unwind:'$comments'},
{$group:{_id:null, max:{$max: '$comments.time'}}});*/

// let x = Topic.aggregate({$match: {replies: 3}}, {$project: {upvotes: {$size: '$comments'}}}, function(e, doc) {
var newId = new mongoose.mongo.ObjectId('123')
let x = Topic.aggregate({$match:{_id: newId}}, {$project: {upvotes: {$size: '$comments'}}}, function(e, doc) {
console.log('-------', doc);

});


