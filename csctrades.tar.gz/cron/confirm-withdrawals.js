/**
 * Created by csctrades.
 */

'use strict';

const log4js = require('log4js');
const CronJob = require('cron').CronJob;
const constants = require('../config/constants');
const Order = require(constants.orderModel);
const fs = require('fs');
let job;

// Load the logger
const logger = log4js.getLogger('confirm-withdrawals');

function withdrawalsJob() {
  let funcName = 'withdrawalsJob';
  logger.info('Function: [[%s]]. Setting up cronjob for withdrawals.....', funcName);
  job = new CronJob({
    cronTime: '00 00 21 * * *',
    onTick: _onTickWithdrawal,
    start: false,
    runOnInit: false // todo delete this
  });

  job.start();

}

/*
* Runs every day (Sunday through Saturday)
* at 09:00:00 PM.
*/
function _onTickWithdrawal() {
  let funcName = '_onTickWithdrawal';
  let withdrawalArrStr, withdrawalArr, orderIds = [];
  logger.info('Function: [[%s]].', funcName);
  try {
    withdrawalArrStr = fs.readFileSync(constants.withdrawals_json, { encoding: 'utf8'});
    withdrawalArr = JSON.parse(withdrawalArrStr);
  } catch (e) {
    logger.error('Function: [[%s]]. Error while parsing/reading withdrawals request. Skipping.....', funcName);
    logger.error('Error:', e);
    return;
  }

  logger.trace('Function: [[%s]]. Withdrawals array:', funcName, withdrawalArr);
  let now = Date.now();
  withdrawalArr.forEach(function (item) {
    orderIds.push(item.orderId);
  });

  if (withdrawalArr.length === 0) {
    logger.error('Function: [[%s]]. No payouts found. Skipping....', funcName);
    return;
  }

  let opt = {
    statusFrom: 'withdrawal_pending',
    statusTo: 'Withdrawn',
    orderIds: orderIds
  };

  Order.updateStatusByOrderIds(opt, updateStatusCB);

  function updateStatusCB(err, rawResponse) {
    let funcName = 'updateStatusCB';
    if (err) {
      logger.error('Function: [[%s]]. Error while updating order statuses', funcName);
      logger.error('Error:', err);
      return;
    }


    logger.info('Function: [[%s]]. Order statuses updated successfully ', funcName);
    logger.debug('Raw response:', rawResponse);
    // Clear withdrawals.json file after succesfully processing it.
    fs.writeFile(constants.withdrawals_json, '[]', writeFileCB);

    function writeFileCB(err) {
      let funcName = 'writeFileCB';
      if (err) {
        logger.error('Function: [[%s]]. Error while clearing [[%s]]',
          funcName, constants.withdrawals_json_keyword);
        return;
      }

      logger.info('Function: [[%s]]. The file [[%s]] has been cleared!',
        funcName, constants.withdrawals_json_keyword);
    }
  }

}


module.exports = withdrawalsJob;