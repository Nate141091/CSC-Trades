/**
 * Created by csctrades.
 */

'use strict';

const log4js = require('log4js');
const request = require('request');
const config = require('config');
const fs = require('fs');
const constants = require('../config/constants');
const Payout = require(constants.payoutModel);
const addr_api_base = config.get('ADDR_API_BASE');
const payout_address = config.get('payout_address');
const CronJob = require('cron').CronJob;
let job;
// Load the logger
const logger = log4js.getLogger('enter-payouts');


function payoutsJob() {
  let funcName = 'payoutsJob';
  logger.info('Function: [[%s]]. Setting up cronjob for payouts.....', funcName);
  job = new CronJob({
    cronTime: '00 00 21 * * *',
    onTick: _onTick,
    start: false,
    runOnInit: false // todo delete this
  });

  job.start();

}

/*
* Runs every day (Sunday through Saturday)
* at 09:00:00 PM.
*/
function _onTick() {
  let funcName = '_onTick';
  let payoutArrStr, payoutArr;
  logger.info('Function: [[%s]].', funcName);
  try {
    payoutArrStr = fs.readFileSync(constants.payout_details_json, { encoding: 'utf8'});
    payoutArr = JSON.parse(payoutArrStr);
  } catch (e) {
    logger.error('Function: [[%s]]. Error while entering payouts. Skipping.....', funcName);
    logger.error('Error:', e);
    return;
  }

  logger.trace('Function: [[%s]]. Payout array:', funcName, payoutArr);
  let now = Date.now();
  payoutArr.forEach(function (item) {
    item.timestamp = now;
  });

  if (payoutArr.length === 0) {
    logger.error('Function: [[%s]]. No payouts found. Skipping....', funcName);
    return;
  }

  Payout.collection.insert(payoutArr, insertCB);

  function insertCB(err, result) {
    let funcName = 'insertCB';
    if (err) {
      logger.error('Function: [[%s]]. Error while inserting customer payouts', funcName)
      logger.error('Error:', err);
      return;
    }

    logger.info('Function: [[%s]]. Inserted count: [[%d]]', funcName, result.insertedCount);
    // todo delete this
    // logger.trace('Result:', result);
    // Clear payout-details.json file after succesfully processing it.
    fs.writeFile(constants.payout_details_json, '[]', writeFileCB);

    function writeFileCB(err) {
      let funcName = 'writeFileCB';
      if (err) {
        logger.error('Function: [[%s]]. Error while clearing [[%s]]',
          funcName, constants.payout_details_json_keyword);
        return;
      }

      logger.info('Function: [[%s]]. The file [[%s]] has been cleared!',
        funcName, constants.payout_details_json_keyword);
    }
  }
}


module.exports = payoutsJob;

