/**
 * Created by Csctrades.
 */

'use strict';

const log4js = require('log4js');
const constants = require('./config/constants');
const request = require('request');
const currencies = [
  'USDEUR',
  'USDGBP',
  'USDCHF',
  'USDAUD',
  'USDJPY',
  'USDCAD',
  'USDHKD',
  'USDNZD',
  'USDSGD',
  'USDRUB'
];

// Load the logger
const logger = log4js.getLogger('currencyRate');

function getCurrencyRates() {
  let funcName = 'getCurrencyRates';
  logger.info('Function: [[%s]]. Initialising cache for currency rates', funcName);
  _updateCache();
  setInterval(_updateCache, 3600000);

};

function _updateCache() {
  let funcName = '_updateCache';
  let cache = {};
  request(constants.currencyRatesApi, function (err, response, body) {
    if (err || (response && response.statusCode !== 200)) {
      logger.error('Function: [[%s]]. Error:', err, '\nStatus Code:',
        funcName, (response ? response.statusCode: null));
      logger.error('Function: [[%s]]. Failed to update cache. Cache not updated. ' + 
        'Retry in 1 hr.');
      return;
    }

    body = JSON.parse(body);
    currencies.forEach(function (item) {
      cache[item] = body.quotes[item]; 
    });

    logger.debug('Function: [[%s]]. Cache:', funcName, cache);
    logger.debug('Function: [[%s]]. Status code: [[%d]]', funcName, response.statusCode);
    // Update the currency cache with latest values.
    global.currencyRate = cache;
    logger.info('Function: [[%s]]. Currency cache updated successfully.', funcName);

  });
}

module.exports = getCurrencyRates;

