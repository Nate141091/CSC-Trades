'use strict';

var ws = new WebSocket("wss://socket.blockcypher.com/v1/btc/main");

ws.onopen = function(event) {
	console.log(event.data);
	ws.send(JSON.stringify({event: "unconfirmed-tx", address: document.getElementById("btcaddr").innerHTML}));
}

ws.onmessage = function (event) {
	console.log(event.data);
	window.location.href = "/thankyou";
}