function subs(email) {
	var email = document.getElementById(email);
    var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    if(re.test(email.value))
    {
    	// $.post('/subscribe',{"email":email.value}).done(function(data){
    		data = {"status":200};
    		if(data.status===200)
            {
            	email.value = "";
            	email.setAttribute("placeholder","You have subscribed successfully!!!");
            }
            else if(data.status===400)
            {
            	email.value = "";
            	email.setAttribute("placeholder","Subscription failed, Try again.");
            }
            else if(data.status===500)
            {
            	email.value = "";
            	email.setAttribute("placeholder","Something went wrong. Try again.");
            }
    	// });
    }
    else
    {
    	email.value = "";
    	email.setAttribute("placeholder","Invalid email. Try again.");
    }
}